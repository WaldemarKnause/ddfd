import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import dotenv from "dotenv";
dotenv.config();

const connection = await mysql.createConnection(process.env.DATABASE_URL);
const db = drizzle(connection);

// Seed professions
await connection.execute(`
  INSERT IGNORE INTO professions (name, slug, description, isActive) VALUES
  ('Маляр', 'malar', 'Промышленный маляр — специалист по нанесению лакокрасочных покрытий на промышленные объекты', true),
  ('Пескоструйщик', 'peskostruyshchik', 'Специалист по абразивной очистке поверхностей методом пескоструйной обработки', true),
  ('Промышленный альпинист', 'promyshlennyy-alpinist', 'Специалист по выполнению работ на высоте с использованием альпинистского снаряжения', true)
`);

console.log("✅ Professions seeded");

// Seed demo jobs
await connection.execute(`
  INSERT IGNORE INTO users (openId, name, email, role) VALUES
  ('demo-employer-1', 'ООО СтройПром', 'employer@demo.ru', 'работодатель')
`);

const [[empRow]] = await connection.execute(`SELECT id FROM users WHERE openId = 'demo-employer-1'`);
const employerId = empRow.id;

const [[prof1]] = await connection.execute(`SELECT id FROM professions WHERE slug = 'malar'`);
const [[prof2]] = await connection.execute(`SELECT id FROM professions WHERE slug = 'peskostruyshchik'`);
const [[prof3]] = await connection.execute(`SELECT id FROM professions WHERE slug = 'promyshlennyy-alpinist'`);

const demoJobs = [
  { title: 'Маляр на промышленный объект', company: 'СтройПром', city: 'Москва', salaryFrom: 80000, salaryTo: 120000, professionId: prof1.id, type: 'полная', desc: 'Требуется опытный маляр для работы на промышленном объекте. Опыт работы от 2 лет.' },
  { title: 'Пескоструйщик на нефтебазу', company: 'НефтеСервис', city: 'Санкт-Петербург', salaryFrom: 90000, salaryTo: 140000, professionId: prof2.id, type: 'вахта', desc: 'Вахтовый метод работы. Проживание и питание предоставляются.' },
  { title: 'Промышленный альпинист', company: 'ВысотаПро', city: 'Екатеринбург', salaryFrom: 100000, salaryTo: 160000, professionId: prof3.id, type: 'полная', desc: 'Выполнение высотных работ на промышленных объектах.' },
  { title: 'Маляр-отделочник', company: 'РемСтрой', city: 'Казань', salaryFrom: 70000, salaryTo: 100000, professionId: prof1.id, type: 'полная', desc: 'Покраска фасадов, нанесение защитных покрытий.' },
  { title: 'Пескоструйщик металлоконструкций', company: 'МеталлГрупп', city: 'Новосибирск', salaryFrom: 85000, salaryTo: 130000, professionId: prof2.id, type: 'договор', desc: 'Очистка металлоконструкций перед нанесением покрытий.' },
  { title: 'Альпинист-монтажник', company: 'ВысотаПро', city: 'Москва', salaryFrom: 120000, salaryTo: 180000, professionId: prof3.id, type: 'полная', desc: 'Монтаж оборудования на высоте, обслуживание фасадов.' },
  { title: 'Маляр по металлу', company: 'ЗаводСтрой', city: 'Челябинск', salaryFrom: 75000, salaryTo: 110000, professionId: prof1.id, type: 'полная', desc: 'Антикоррозийная обработка металлических конструкций.' },
  { title: 'Пескоструйщик (вахта)', company: 'СевернаяВахта', city: 'Сургут', salaryFrom: 110000, salaryTo: 150000, professionId: prof2.id, type: 'вахта', desc: 'Вахта 30/30. Работа на нефтегазовых объектах.' },
  { title: 'Промышленный альпинист-сварщик', company: 'ПромТех', city: 'Уфа', salaryFrom: 130000, salaryTo: 200000, professionId: prof3.id, type: 'полная', desc: 'Сварочные работы на высоте. Допуск к работам на высоте обязателен.' },
];

for (const job of demoJobs) {
  await connection.execute(
    `INSERT IGNORE INTO jobs (title, description, company, city, salaryFrom, salaryTo, employmentType, professionId, employerId, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'активна')`,
    [job.title, job.desc, job.company, job.city, job.salaryFrom, job.salaryTo, job.type, job.professionId, employerId]
  );
}

console.log("✅ Demo jobs seeded");
await connection.end();
console.log("✅ Seed complete");
