-- ПромРабота: Создание базы данных и таблиц
-- Импортируй этот файл в phpMyAdmin: выбери базу industrial_jobs -> Импорт -> выбери этот файл

CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `openId` varchar(64) NOT NULL,
  `name` text,
  `email` varchar(320) DEFAULT NULL,
  `loginMethod` varchar(64) DEFAULT NULL,
  `role` enum('user','admin','соискатель','работодатель','админ') NOT NULL DEFAULT 'user',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `lastSignedIn` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_openId_unique` (`openId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `professions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text,
  `icon` varchar(64) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `professions_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `jobs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `requirements` text,
  `company` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `salaryFrom` int DEFAULT NULL,
  `salaryTo` int DEFAULT NULL,
  `currency` varchar(10) NOT NULL DEFAULT 'RUB',
  `employmentType` enum('полная','частичная','вахта','договор') NOT NULL DEFAULT 'полная',
  `professionId` int NOT NULL,
  `employerId` int NOT NULL,
  `status` enum('активна','закрыта','черновик') NOT NULL DEFAULT 'активна',
  `viewsCount` int NOT NULL DEFAULT '0',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `jobs_professionId_idx` (`professionId`),
  KEY `jobs_employerId_idx` (`employerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `applications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `jobId` int NOT NULL,
  `seekerId` int NOT NULL,
  `coverLetter` text,
  `status` enum('новый','просмотрен','приглашён','отклонён') NOT NULL DEFAULT 'новый',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `applications_jobId_seekerId_unique` (`jobId`,`seekerId`),
  KEY `applications_jobId_idx` (`jobId`),
  KEY `applications_seekerId_idx` (`seekerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `seeker_profiles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `bio` text,
  `phone` varchar(32) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `experience` text,
  `resumeUrl` varchar(500) DEFAULT NULL,
  `resumeKey` varchar(500) DEFAULT NULL,
  `photoUrl` varchar(500) DEFAULT NULL,
  `photoKey` varchar(500) DEFAULT NULL,
  `professionId` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `seeker_profiles_userId_unique` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `employer_profiles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `companyName` varchar(255) DEFAULT NULL,
  `description` text,
  `website` varchar(500) DEFAULT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `logoUrl` varchar(500) DEFAULT NULL,
  `logoKey` varchar(500) DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employer_profiles_userId_unique` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `saved_jobs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `jobId` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `saved_jobs_userId_jobId_unique` (`userId`,`jobId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `drizzle_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hash` text NOT NULL,
  `created_at` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Начальные данные: профессии
INSERT IGNORE INTO `professions` (`name`, `slug`, `description`, `icon`, `isActive`) VALUES
('Маляр', 'malar', 'Промышленный маляр — специалист по покраске промышленных объектов, металлоконструкций и зданий', 'Paintbrush', 1),
('Пескоструйщик', 'peskostruyshchik', 'Специалист по пескоструйной обработке поверхностей — очистка металла, бетона и других материалов', 'Wind', 1),
('Промышленный альпинист', 'promyshlennyy-alpinist', 'Высотный специалист, выполняющий работы на высоте с использованием альпинистского снаряжения', 'Mountain', 1);

-- Тестовые вакансии (employerId=1 — заглушка, замени на реального пользователя)
INSERT IGNORE INTO `users` (`id`, `openId`, `name`, `email`, `role`) VALUES
(1, 'demo-employer-1', 'ООО Промстрой', 'demo@promstroy.ru', 'работодатель');

INSERT IGNORE INTO `jobs` (`title`, `description`, `requirements`, `company`, `city`, `salaryFrom`, `salaryTo`, `employmentType`, `professionId`, `employerId`, `status`) VALUES
('Промышленный маляр на объект', 'Требуется маляр для покраски металлоконструкций на производственном объекте в Москве. Работа вахтовым методом, проживание и питание предоставляется.', 'Опыт работы от 2 лет. Наличие допуска к работам на высоте. Знание технологий нанесения антикоррозийных покрытий.', 'ООО Промстрой', 'Москва', 80000, 120000, 'вахта', 1, 1, 'активна'),
('Пескоструйщик на завод', 'Приглашаем пескоструйщика для работы на металлообрабатывающем заводе. Постоянная занятость, официальное трудоустройство.', 'Опыт работы с пескоструйным оборудованием от 1 года. Знание техники безопасности.', 'Завод Металлист', 'Санкт-Петербург', 70000, 100000, 'полная', 2, 1, 'активна'),
('Промышленный альпинист', 'Ищем промышленного альпиниста для выполнения высотных работ на объектах нефтегазового сектора.', 'Удостоверение промышленного альпиниста. Опыт работы от 3 лет. Медицинская справка.', 'НефтеСтрой', 'Тюмень', 100000, 150000, 'вахта', 3, 1, 'активна'),
('Маляр-отделочник', 'Требуется маляр для отделочных работ на крупном строительном объекте. Работа в Екатеринбурге, возможно проживание.', 'Опыт отделочных работ от 1 года. Умение работать с различными видами красок и покрытий.', 'СтройГрупп', 'Екатеринбург', 60000, 90000, 'полная', 1, 1, 'активна'),
('Пескоструйщик-маляр', 'Совмещение профессий: пескоструйная обработка и последующая покраска металлоконструкций. Вахта 30/30.', 'Опыт работы по обеим специальностям. Наличие допусков.', 'ПромТех', 'Новосибирск', 90000, 130000, 'вахта', 2, 1, 'активна'),
('Высотник-монтажник', 'Промышленный альпинист для монтажных работ на башнях и мачтах связи по всей России.', 'Удостоверение промышленного альпиниста. Опыт монтажных работ на высоте.', 'ТелекомМонтаж', 'Москва', 120000, 180000, 'вахта', 3, 1, 'активна');
