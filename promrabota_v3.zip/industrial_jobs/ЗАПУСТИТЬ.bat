@echo off
chcp 65001 >nul
echo.
echo ============================================
echo    ПромРабота - Запуск сайта
echo ============================================
echo.

if not exist ".env" (
    copy ".env.example" ".env" >nul
    echo [OK] Создан файл .env
)

echo [..] Запускаем сервер...
echo.
echo Когда появится "Server running on http://localhost:3000/"
echo откройте браузер и перейдите на: http://localhost:3000
echo.
echo Для остановки нажмите Ctrl+C
echo.
pnpm dev
pause
