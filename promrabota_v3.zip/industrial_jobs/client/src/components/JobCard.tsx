import { Link } from "wouter";
import { MapPin, Briefcase, Clock, ChevronRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface JobCardProps {
  id: number;
  title: string;
  company: string;
  city: string;
  salaryFrom?: number | null;
  salaryTo?: number | null;
  currency?: string;
  employmentType: string;
  professionName?: string | null;
  createdAt?: Date | string;
  compact?: boolean;
}

const employmentTypeColors: Record<string, string> = {
  "полная": "bg-blue-500/10 text-blue-500 border-blue-500/20 dark:bg-blue-400/15 dark:text-blue-400 dark:border-blue-400/25",
  "частичная": "bg-purple-500/10 text-purple-600 border-purple-500/20 dark:bg-purple-400/15 dark:text-purple-400 dark:border-purple-400/25",
  "вахта": "bg-orange-500/10 text-orange-600 border-orange-500/20 dark:bg-orange-400/15 dark:text-orange-400 dark:border-orange-400/25",
  "договор": "bg-green-500/10 text-green-600 border-green-500/20 dark:bg-green-400/15 dark:text-green-400 dark:border-green-400/25",
};

function formatSalary(from?: number | null, to?: number | null, currency = "₽") {
  if (!from && !to) return "Зарплата не указана";
  if (from && to) return `${from.toLocaleString("ru")} – ${to.toLocaleString("ru")} ${currency}`;
  if (from) return `от ${from.toLocaleString("ru")} ${currency}`;
  if (to) return `до ${to.toLocaleString("ru")} ${currency}`;
  return "";
}

function timeAgo(date?: Date | string) {
  if (!date) return "";
  const d = new Date(date);
  const now = new Date();
  const diff = Math.floor((now.getTime() - d.getTime()) / 1000);
  if (diff < 60) return "только что";
  if (diff < 3600) return `${Math.floor(diff / 60)} мин. назад`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} ч. назад`;
  if (diff < 2592000) return `${Math.floor(diff / 86400)} дн. назад`;
  return d.toLocaleDateString("ru-RU");
}

export default function JobCard({
  id,
  title,
  company,
  city,
  salaryFrom,
  salaryTo,
  currency,
  employmentType,
  professionName,
  createdAt,
  compact = false,
}: JobCardProps) {
  return (
    <Link href={`/jobs/${id}`}>
      <div className={`job-card bg-card rounded-2xl border border-border cursor-pointer group ${compact ? "p-4" : "p-5"}`}>
        <div className="flex items-start justify-between gap-3">
          {/* Company avatar */}
          <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-accent flex items-center justify-center text-primary font-bold text-sm">
            {company.charAt(0).toUpperCase()}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-1">
              <h3 className={`font-semibold text-foreground group-hover:text-primary transition-colors leading-tight ${compact ? "text-sm" : "text-base"}`}>
                {title}
              </h3>
              <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0 mt-0.5 group-hover:text-primary transition-colors" />
            </div>

            <p className="text-sm text-muted-foreground mb-3 truncate">{company}</p>

            <div className="flex flex-wrap items-center gap-2">
              {/* Salary */}
              <span className="text-sm font-semibold text-foreground">
                {formatSalary(salaryFrom, salaryTo, currency)}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2 mt-2">
              {/* City */}
              <span className="flex items-center gap-1 text-xs text-muted-foreground">
                <MapPin className="w-3 h-3" />
                {city}
              </span>

              {/* Employment type */}
              <Badge
                variant="outline"
                className={`text-xs px-2 py-0.5 font-medium ${employmentTypeColors[employmentType] || "bg-muted text-muted-foreground"}`}
              >
                {employmentType}
              </Badge>

              {/* Profession */}
              {professionName && (
                <Badge variant="outline" className="text-xs px-2 py-0.5 bg-secondary text-secondary-foreground border-secondary">
                  {professionName}
                </Badge>
              )}

              {/* Time */}
              {createdAt && (
                <span className="flex items-center gap-1 text-xs text-muted-foreground ml-auto">
                  <Clock className="w-3 h-3" />
                  {timeAgo(createdAt)}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
