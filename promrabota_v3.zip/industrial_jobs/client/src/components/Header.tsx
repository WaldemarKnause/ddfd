import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Link, useLocation } from "wouter";
import { HardHat, ChevronDown, LogOut, User, Briefcase, Shield, Sun, Moon, Map } from "lucide-react";
import { useTheme } from "@/contexts/ThemeContext";
import { toast } from "sonner";

export default function Header() {
  const { user, isAuthenticated, logout } = useAuth();
  const [location] = useLocation();
  const { theme, toggleTheme, switchable } = useTheme();

  const handleLogout = async () => {
    await logout();
    toast.success("Вы вышли из системы");
  };

  const roleLabel = user?.role === "работодатель"
    ? "Работодатель"
    : user?.role === "админ"
    ? "Администратор"
    : "Соискатель";

  const dashboardPath = user?.role === "работодатель"
    ? "/dashboard/employer"
    : user?.role === "админ"
    ? "/admin"
    : "/dashboard/seeker";

  return (
    <header className="sticky top-0 z-50 bg-background/90 backdrop-blur-md border-b border-border transition-colors duration-300">
      <div className="container">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 font-bold text-xl text-foreground hover:opacity-80 transition-opacity">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <HardHat className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="hidden sm:block">
              Пром<span className="text-primary">Работа</span>
            </span>
          </Link>

          {/* Nav */}
          <nav className="hidden md:flex items-center gap-6">
            <Link
              href="/jobs"
              className={`text-sm font-medium transition-colors hover:text-primary ${location === "/jobs" ? "text-primary" : "text-muted-foreground"}`}
            >
              Вакансии
            </Link>
            <Link
              href="/map"
              className={`text-sm font-medium transition-colors hover:text-primary flex items-center gap-1 ${location === "/map" ? "text-primary" : "text-muted-foreground"}`}
            >
              <Map className="w-3.5 h-3.5" />
              Карта
            </Link>
            {isAuthenticated && (user?.role === "работодатель" || user?.role === "админ") && (
              <Link
                href="/jobs/new"
                className={`text-sm font-medium transition-colors hover:text-primary ${location === "/jobs/new" ? "text-primary" : "text-muted-foreground"}`}
              >
                Разместить вакансию
              </Link>
            )}
          </nav>

          {/* Right side: theme toggle + auth */}
          <div className="flex items-center gap-2">
            {/* Theme toggle */}
            {switchable && toggleTheme && (
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                className="w-9 h-9 rounded-lg text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
                title={theme === "dark" ? "Светлая тема" : "Тёмная тема"}
              >
                {theme === "dark" ? (
                  <Sun className="w-4 h-4" />
                ) : (
                  <Moon className="w-4 h-4" />
                )}
              </Button>
            )}

            {/* Auth */}
            {isAuthenticated && user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center gap-2 h-9 px-3">
                    <Avatar className="w-7 h-7">
                      <AvatarFallback className="bg-primary text-primary-foreground text-xs font-semibold">
                        {(user.name || user.email || "U").charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <span className="hidden sm:block text-sm font-medium max-w-[120px] truncate">
                      {user.name || user.email}
                    </span>
                    <ChevronDown className="w-4 h-4 text-muted-foreground" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-52">
                  <div className="px-3 py-2">
                    <p className="text-xs text-muted-foreground">{roleLabel}</p>
                    <p className="text-sm font-medium truncate">{user.name || user.email}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href={dashboardPath} className="flex items-center gap-2 cursor-pointer">
                      {user.role === "админ" ? (
                        <Shield className="w-4 h-4" />
                      ) : user.role === "работодатель" ? (
                        <Briefcase className="w-4 h-4" />
                      ) : (
                        <User className="w-4 h-4" />
                      )}
                      Личный кабинет
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:text-destructive">
                    <LogOut className="w-4 h-4 mr-2" />
                    Выйти
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center gap-2">
                <Button asChild variant="ghost" size="sm">
                  <Link href="/login">Войти</Link>
                </Button>
                <Button asChild size="sm" className="hidden sm:flex">
                  <Link href="/register">Регистрация</Link>
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
