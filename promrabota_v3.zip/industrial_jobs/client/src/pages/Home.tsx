import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import JobCard from "@/components/JobCard";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, MapPin, Briefcase, ChevronRight, HardHat, Wrench, Mountain, Clock } from "lucide-react";

const PROFESSION_ICONS: Record<string, React.ReactNode> = {
  "malar": <Wrench className="w-6 h-6" />,
  "peskostruyshchik": <HardHat className="w-6 h-6" />,
  "promyshlennyy-alpinist": <Mountain className="w-6 h-6" />,
};

const CITIES = ["Москва", "Санкт-Петербург", "Новосибирск", "Екатеринбург", "Казань", "Нижний Новгород", "Челябинск", "Самара", "Уфа", "Ростов-на-Дону"];

export default function Home() {
  const [, navigate] = useLocation();
  const [search, setSearch] = useState("");
  const [city, setCity] = useState("");
  const [professionId, setProfessionId] = useState<string>("");
  const [employmentType, setEmploymentType] = useState<string>("");

  const { data: professions } = trpc.professions.list.useQuery();
  const { data: latestJobs } = trpc.jobs.list.useQuery({ page: 1, limit: 6 });

  const handleSearch = () => {
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    if (city && city !== "all") params.set("city", city);
    if (professionId && professionId !== "all") params.set("professionId", professionId);
    if (employmentType && employmentType !== "all") params.set("employmentType", employmentType);
    navigate(`/jobs?${params.toString()}`);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") handleSearch();
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-background via-accent/20 to-background pt-16 pb-20">
        {/* Decorative geometric blobs */}
        <div className="absolute top-0 right-0 w-96 h-96 geo-blob-blue opacity-60 translate-x-1/3 -translate-y-1/4 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 geo-blob-pink opacity-50 -translate-x-1/4 translate-y-1/4 pointer-events-none" />
        <div className="absolute top-1/2 left-1/2 w-64 h-64 geo-blob-blue opacity-20 -translate-x-1/2 -translate-y-1/2 pointer-events-none" />

        <div className="container relative z-10 max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-card/80 backdrop-blur-sm border border-border rounded-full px-4 py-1.5 text-sm text-muted-foreground mb-6 shadow-sm">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            {latestJobs?.total || 0} активных вакансий
          </div>

          {/* Heading */}
          <h1 className="text-5xl md:text-6xl font-extrabold text-foreground leading-tight tracking-tight mb-4">
            Работа для<br />
            <span className="text-primary">профессионалов</span>
          </h1>
          <p className="text-lg text-muted-foreground mb-10 max-w-xl mx-auto font-light">
            Маляры, пескоструйщики, промышленные альпинисты — найди свою вакансию или размести объявление
          </p>

          {/* Search bar */}
          <div className="bg-card rounded-2xl shadow-lg border border-border p-2 flex flex-col md:flex-row gap-2 max-w-3xl mx-auto search-bar">
            <div className="flex-1 flex items-center gap-2 px-3">
              <Search className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Должность, ключевые слова..."
                className="border-0 shadow-none focus-visible:ring-0 bg-transparent p-0 text-sm"
              />
            </div>
            <div className="w-px bg-border hidden md:block self-stretch my-1" />
            <div className="flex items-center gap-2 px-3 md:w-44">
              <MapPin className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <Select value={city} onValueChange={setCity}>
                <SelectTrigger className="border-0 shadow-none focus:ring-0 bg-transparent p-0 text-sm h-auto">
                  <SelectValue placeholder="Город" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Все города</SelectItem>
                  {CITIES.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="w-px bg-border hidden md:block self-stretch my-1" />
            <div className="flex items-center gap-2 px-3 md:w-48">
              <Briefcase className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <Select value={professionId} onValueChange={setProfessionId}>
                <SelectTrigger className="border-0 shadow-none focus:ring-0 bg-transparent p-0 text-sm h-auto">
                  <SelectValue placeholder="Профессия" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Все профессии</SelectItem>
                  {professions?.map((p) => (
                    <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="w-px bg-border hidden md:block self-stretch my-1" />
            <div className="flex items-center gap-2 px-3 md:w-44">
              <Clock className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <Select value={employmentType} onValueChange={setEmploymentType}>
                <SelectTrigger className="border-0 shadow-none focus:ring-0 bg-transparent p-0 text-sm h-auto">
                  <SelectValue placeholder="Занятость" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Любая</SelectItem>
                  <SelectItem value="полная">Полная</SelectItem>
                  <SelectItem value="частичная">Частичная</SelectItem>
                  <SelectItem value="вахта">Вахта</SelectItem>
                  <SelectItem value="договор">По договору</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={handleSearch} size="lg" className="rounded-xl px-8 font-semibold">
              Найти
            </Button>
          </div>
        </div>
      </section>

      {/* Professions Section */}
      <section className="py-14 bg-card/50">
        <div className="container max-w-5xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-foreground">Профессии</h2>
            <Button variant="ghost" size="sm" onClick={() => navigate("/jobs")} className="text-muted-foreground hover:text-foreground gap-1">
              Все вакансии <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {professions?.map((prof) => (
              <button
                key={prof.id}
                onClick={() => navigate(`/jobs?professionId=${prof.id}`)}
                className="group text-left bg-card border border-border rounded-2xl p-6 hover:border-primary/30 hover:shadow-md transition-all duration-200"
              >
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary mb-4 group-hover:bg-primary/20 transition-colors">
                  {PROFESSION_ICONS[prof.slug] || <Briefcase className="w-6 h-6" />}
                </div>
                <h3 className="font-semibold text-foreground mb-1">{prof.name}</h3>
                <p className="text-sm text-muted-foreground line-clamp-2">{prof.description}</p>
                <div className="flex items-center gap-1 mt-3 text-primary text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                  Смотреть вакансии <ChevronRight className="w-4 h-4" />
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Latest Jobs */}
      <section className="py-14 bg-background">
        <div className="container max-w-5xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-foreground">Свежие вакансии</h2>
            <Button variant="ghost" size="sm" onClick={() => navigate("/jobs")} className="text-muted-foreground hover:text-foreground gap-1">
              Все вакансии <ChevronRight className="w-4 h-4" />
            </Button>
          </div>

          {!latestJobs ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="bg-card rounded-2xl border border-border p-5 animate-pulse h-32" />
              ))}
            </div>
          ) : latestJobs.items.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              Вакансий пока нет. Станьте первым работодателем!
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {latestJobs.items.map((job) => (
                <JobCard key={job.id} {...job} />
              ))}
            </div>
          )}

          {latestJobs && latestJobs.total > 6 && (
            <div className="text-center mt-8">
              <Button variant="outline" size="lg" onClick={() => navigate("/jobs")} className="rounded-xl px-8">
                Смотреть все {latestJobs.total} вакансий
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* CTA for employers */}
      <section className="py-14 bg-card/50">
        <div className="container max-w-5xl mx-auto">
          <div className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-accent/30 to-background rounded-3xl p-10 text-center border border-border">
            <div className="absolute top-0 right-0 w-64 h-64 geo-blob-blue opacity-30 translate-x-1/4 -translate-y-1/4 pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-48 h-48 geo-blob-pink opacity-25 -translate-x-1/4 translate-y-1/4 pointer-events-none" />
            <div className="relative z-10">
              <Badge className="mb-4 bg-primary/10 text-primary border-0">Для работодателей</Badge>
              <h2 className="text-3xl font-bold text-foreground mb-3">Найдите специалиста</h2>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                Разместите вакансию и получайте отклики от квалифицированных промышленных специалистов
              </p>
              <Button size="lg" onClick={() => navigate("/jobs/new")} className="rounded-xl px-8 font-semibold">
                Разместить вакансию
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-border bg-background">
        <div className="container max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
              <HardHat className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-foreground">ПромРабота</span>
          </div>
          <p className="text-sm text-muted-foreground">© 2025 ПромРабота — вакансии для промышленных профессионалов</p>
          <div className="flex gap-4 text-sm text-muted-foreground">
            <button onClick={() => navigate("/jobs")} className="hover:text-foreground transition-colors">Вакансии</button>
            <button onClick={() => navigate("/jobs/new")} className="hover:text-foreground transition-colors">Разместить</button>
          </div>
        </div>
      </footer>
    </div>
  );
}
