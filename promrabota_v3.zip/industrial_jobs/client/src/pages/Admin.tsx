import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Shield,
  Briefcase,
  Users,
  Tag,
  Plus,
  Pencil,
  Trash2,
  BarChart3,
  CheckCircle2,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";

export default function Admin() {
  const { user } = useAuth();
  const utils = trpc.useUtils();

  const { data: stats } = trpc.admin.stats.useQuery();
  const { data: usersData } = trpc.admin.users.useQuery({ page: 1 });
  const { data: jobsData } = trpc.jobs.adminList.useQuery({ page: 1 });
  const { data: professions } = trpc.professions.listAll.useQuery();

  const [newProfName, setNewProfName] = useState("");
  const [newProfSlug, setNewProfSlug] = useState("");
  const [newProfDesc, setNewProfDesc] = useState("");
  const [editProf, setEditProf] = useState<any>(null);

  const createProfMutation = trpc.professions.create.useMutation({
    onSuccess: () => {
      toast.success("Профессия добавлена");
      utils.professions.listAll.invalidate();
      utils.professions.list.invalidate();
      setNewProfName("");
      setNewProfSlug("");
      setNewProfDesc("");
    },
    onError: (err) => toast.error(err.message),
  });

  const updateProfMutation = trpc.professions.update.useMutation({
    onSuccess: () => {
      toast.success("Профессия обновлена");
      utils.professions.listAll.invalidate();
      utils.professions.list.invalidate();
      setEditProf(null);
    },
  });

  const deleteProfMutation = trpc.professions.delete.useMutation({
    onSuccess: () => {
      toast.success("Профессия деактивирована");
      utils.professions.listAll.invalidate();
      utils.professions.list.invalidate();
    },
  });

  const updateRoleMutation = trpc.admin.updateUserRole.useMutation({
    onSuccess: () => {
      toast.success("Роль обновлена");
      utils.admin.users.invalidate();
    },
  });

  const deleteJobMutation = trpc.jobs.delete.useMutation({
    onSuccess: () => {
      toast.success("Вакансия закрыта");
      utils.jobs.adminList.invalidate();
    },
  });

  if (user?.role !== "админ") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Shield className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
          <h2 className="text-xl font-semibold mb-2">Доступ запрещён</h2>
          <p className="text-muted-foreground">Только администраторы могут просматривать эту страницу</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8">
      <div className="container max-w-6xl">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Shield className="w-6 h-6 text-primary" />
            Панель администратора
          </h1>
          <p className="text-muted-foreground mt-1">Управление платформой</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="bg-card rounded-2xl border border-border p-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
                <Briefcase className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{stats?.jobs ?? 0}</p>
                <p className="text-xs text-muted-foreground">Активных вакансий</p>
              </div>
            </div>
          </div>
          <div className="bg-card rounded-2xl border border-border p-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-green-50 flex items-center justify-center">
                <Users className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{stats?.users ?? 0}</p>
                <p className="text-xs text-muted-foreground">Пользователей</p>
              </div>
            </div>
          </div>
          <div className="bg-card rounded-2xl border border-border p-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-50 flex items-center justify-center">
                <BarChart3 className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{stats?.applications ?? 0}</p>
                <p className="text-xs text-muted-foreground">Откликов</p>
              </div>
            </div>
          </div>
        </div>

        <Tabs defaultValue="professions">
          <TabsList className="mb-6">
            <TabsTrigger value="professions" className="flex items-center gap-2">
              <Tag className="w-4 h-4" />
              Профессии
            </TabsTrigger>
            <TabsTrigger value="jobs" className="flex items-center gap-2">
              <Briefcase className="w-4 h-4" />
              Вакансии
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Пользователи
            </TabsTrigger>
          </TabsList>

          {/* Professions */}
          <TabsContent value="professions">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Add Profession */}
              <div className="bg-card rounded-2xl border border-border p-6">
                <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  Добавить профессию
                </h3>
                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Название *</label>
                    <Input value={newProfName} onChange={(e) => {
                      setNewProfName(e.target.value);
                      setNewProfSlug(e.target.value.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-а-яё]/gi, ""));
                    }} placeholder="Сварщик" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Slug (URL) *</label>
                    <Input value={newProfSlug} onChange={(e) => setNewProfSlug(e.target.value)} placeholder="svarshchik" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Описание</label>
                    <Textarea value={newProfDesc} onChange={(e) => setNewProfDesc(e.target.value)} placeholder="Краткое описание профессии..." rows={2} className="resize-none" />
                  </div>
                  <Button
                    onClick={() => createProfMutation.mutate({ name: newProfName, slug: newProfSlug, description: newProfDesc || undefined })}
                    disabled={createProfMutation.isPending || !newProfName || !newProfSlug}
                    className="w-full"
                  >
                    Добавить профессию
                  </Button>
                </div>
              </div>

              {/* Professions List */}
              <div className="bg-card rounded-2xl border border-border p-6">
                <h3 className="font-semibold text-foreground mb-4">Список профессий</h3>
                <div className="space-y-2">
                  {professions?.map((p) => (
                    <div key={p.id} className="flex items-center justify-between p-3 rounded-xl bg-background border border-border">
                      <div className="flex items-center gap-2">
                        {p.isActive ? (
                          <CheckCircle2 className="w-4 h-4 text-green-500" />
                        ) : (
                          <XCircle className="w-4 h-4 text-muted-foreground" />
                        )}
                        <div>
                          <p className="text-sm font-medium text-foreground">{p.name}</p>
                          <p className="text-xs text-muted-foreground">{p.slug}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="sm" onClick={() => setEditProf(p)}>
                          <Pencil className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteProfMutation.mutate({ id: p.id })}
                          className="text-muted-foreground hover:text-destructive"
                          disabled={!p.isActive}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Jobs */}
          <TabsContent value="jobs">
            <div className="bg-card rounded-2xl border border-border overflow-hidden">
              <div className="p-4 border-b border-border">
                <h3 className="font-semibold text-foreground">Все вакансии</h3>
              </div>
              <div className="divide-y divide-border">
                {jobsData?.items.map((job) => (
                  <div key={job.id} className="flex items-center justify-between p-4 hover:bg-muted/30 transition-colors">
                    <div className="flex-1 min-w-0">
                      <Link href={`/jobs/${job.id}`} className="font-medium text-foreground hover:text-primary transition-colors text-sm">
                        {job.title}
                      </Link>
                      <p className="text-xs text-muted-foreground">{job.company} · {job.city}</p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <Badge
                        variant="outline"
                        className={`text-xs ${job.status === "активна" ? "bg-green-500/10 text-green-600 dark:bg-green-400/15 dark:text-green-400" : "bg-gray-50 text-gray-600"}`}
                      >
                        {job.status}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteJobMutation.mutate({ id: job.id })}
                        className="text-muted-foreground hover:text-destructive"
                        disabled={job.status === "закрыта"}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Users */}
          <TabsContent value="users">
            <div className="bg-card rounded-2xl border border-border overflow-hidden">
              <div className="p-4 border-b border-border">
                <h3 className="font-semibold text-foreground">Пользователи</h3>
              </div>
              <div className="divide-y divide-border">
                {usersData?.items.map((u) => (
                  <div key={u.id} className="flex items-center justify-between p-4 hover:bg-muted/30 transition-colors">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground text-sm">{u.name || "—"}</p>
                      <p className="text-xs text-muted-foreground">{u.email || u.openId}</p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <Select
                        value={u.role}
                        onValueChange={(v) => updateRoleMutation.mutate({
                          userId: u.id,
                          role: v as "соискатель" | "работодатель" | "админ",
                        })}
                        disabled={u.id === user?.id}
                      >
                        <SelectTrigger className="w-36 h-8 text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="соискатель">Соискатель</SelectItem>
                          <SelectItem value="работодатель">Работодатель</SelectItem>
                          <SelectItem value="админ">Администратор</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Edit Profession Dialog */}
        <Dialog open={!!editProf} onOpenChange={() => setEditProf(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Редактировать профессию</DialogTitle>
            </DialogHeader>
            {editProf && (
              <div className="space-y-3 py-2">
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Название</label>
                  <Input
                    value={editProf.name}
                    onChange={(e) => setEditProf({ ...editProf, name: e.target.value })}
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Описание</label>
                  <Textarea
                    value={editProf.description || ""}
                    onChange={(e) => setEditProf({ ...editProf, description: e.target.value })}
                    rows={3}
                    className="resize-none"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="isActive"
                    checked={editProf.isActive}
                    onChange={(e) => setEditProf({ ...editProf, isActive: e.target.checked })}
                    className="rounded"
                  />
                  <label htmlFor="isActive" className="text-sm">Активна</label>
                </div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditProf(null)}>Отмена</Button>
              <Button
                onClick={() => updateProfMutation.mutate({
                  id: editProf.id,
                  name: editProf.name,
                  description: editProf.description,
                  isActive: editProf.isActive,
                })}
                disabled={updateProfMutation.isPending}
              >
                Сохранить
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
