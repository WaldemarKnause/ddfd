import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Users, Building2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export default function RoleSelect() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const utils = trpc.useUtils();

  const setRoleMutation = trpc.user.setRole.useMutation({
    onSuccess: async (_, vars) => {
      await utils.auth.me.invalidate();
      toast.success("Роль выбрана!");
      if (vars.role === "работодатель") {
        navigate("/dashboard/employer");
      } else {
        navigate("/dashboard/seeker");
      }
    },
    onError: (err) => toast.error(err.message),
  });

  if (user?.role !== "соискатель" && user?.role !== "работодатель") {
    // Already has a specific role or is admin
    navigate("/");
    return null;
  }

  return (
    <div className="min-h-screen flex items-center justify-center py-12">
      <div className="container max-w-2xl">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-foreground mb-3">Добро пожаловать!</h1>
          <p className="text-muted-foreground text-lg">
            Выберите, кем вы являетесь на платформе
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Seeker */}
          <button
            onClick={() => setRoleMutation.mutate({ role: "соискатель" })}
            disabled={setRoleMutation.isPending}
            className="group bg-card rounded-2xl border-2 border-border hover:border-primary p-8 text-left transition-all hover:shadow-lg"
          >
            <div className="w-14 h-14 rounded-2xl bg-accent flex items-center justify-center mb-4 group-hover:bg-primary/10 transition-colors">
              <Users className="w-7 h-7 text-primary" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">Я ищу работу</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Откликайтесь на вакансии, сохраняйте интересные предложения, загружайте резюме
            </p>
            <div className="mt-4 space-y-1">
              {["Просмотр вакансий", "Отправка откликов", "Загрузка резюме", "Сохранение вакансий"].map((f) => (
                <div key={f} className="flex items-center gap-2 text-xs text-muted-foreground">
                  <CheckCircle2 className="w-3.5 h-3.5 text-green-500" />
                  {f}
                </div>
              ))}
            </div>
          </button>

          {/* Employer */}
          <button
            onClick={() => setRoleMutation.mutate({ role: "работодатель" })}
            disabled={setRoleMutation.isPending}
            className="group bg-card rounded-2xl border-2 border-border hover:border-primary p-8 text-left transition-all hover:shadow-lg"
          >
            <div className="w-14 h-14 rounded-2xl bg-accent flex items-center justify-center mb-4 group-hover:bg-primary/10 transition-colors">
              <Building2 className="w-7 h-7 text-primary" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">Я работодатель</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Размещайте вакансии, просматривайте отклики, находите специалистов
            </p>
            <div className="mt-4 space-y-1">
              {["Размещение вакансий", "Просмотр откликов", "Управление вакансиями", "Профиль компании"].map((f) => (
                <div key={f} className="flex items-center gap-2 text-xs text-muted-foreground">
                  <CheckCircle2 className="w-3.5 h-3.5 text-green-500" />
                  {f}
                </div>
              ))}
            </div>
          </button>
        </div>

        <p className="text-center text-xs text-muted-foreground mt-6">
          Роль можно изменить позже в настройках профиля
        </p>
      </div>
    </div>
  );
}
