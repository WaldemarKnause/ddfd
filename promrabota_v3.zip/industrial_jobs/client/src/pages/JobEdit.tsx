import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function JobEdit() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const utils = trpc.useUtils();

  const jobId = Number(id);
  const { data: job, isLoading } = trpc.jobs.byId.useQuery({ id: jobId }, { enabled: !!jobId });
  const { data: professions } = trpc.professions.list.useQuery();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [requirements, setRequirements] = useState("");
  const [company, setCompany] = useState("");
  const [city, setCity] = useState("");
  const [salaryFrom, setSalaryFrom] = useState("");
  const [salaryTo, setSalaryTo] = useState("");
  const [employmentType, setEmploymentType] = useState<"полная" | "частичная" | "вахта" | "договор">("полная");
  const [professionId, setProfessionId] = useState("");
  const [status, setStatus] = useState<"активна" | "закрыта" | "черновик">("активна");

  useEffect(() => {
    if (job) {
      setTitle(job.title);
      setDescription(job.description);
      setRequirements(job.requirements || "");
      setCompany(job.company);
      setCity(job.city);
      setSalaryFrom(job.salaryFrom ? String(job.salaryFrom) : "");
      setSalaryTo(job.salaryTo ? String(job.salaryTo) : "");
      setEmploymentType(job.employmentType as "полная" | "частичная" | "вахта" | "договор");
      setProfessionId(String(job.professionId));
      setStatus(job.status as "активна" | "закрыта" | "черновик");
    }
  }, [job]);

  const updateMutation = trpc.jobs.update.useMutation({
    onSuccess: () => {
      toast.success("Вакансия обновлена");
      utils.jobs.myJobs.invalidate();
      utils.jobs.byId.invalidate({ id: jobId });
      navigate("/dashboard/employer");
    },
    onError: (err) => {
      toast.error(err.message || "Ошибка при обновлении вакансии");
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!job) {
    return (
      <div className="min-h-screen py-8">
        <div className="container max-w-2xl text-center py-20">
          <p className="text-muted-foreground">Вакансия не найдена</p>
          <Button onClick={() => navigate("/dashboard/employer")} variant="outline" className="mt-4">
            В кабинет
          </Button>
        </div>
      </div>
    );
  }

  if (user && job.employerId !== user.id && user.role !== "админ") {
    return (
      <div className="min-h-screen py-8">
        <div className="container max-w-2xl text-center py-20">
          <p className="text-muted-foreground">У вас нет прав для редактирования этой вакансии</p>
        </div>
      </div>
    );
  }

  const handleSubmit = () => {
    if (!title.trim() || !description.trim() || !company.trim() || !city.trim() || !professionId) {
      toast.error("Заполните все обязательные поля");
      return;
    }
    updateMutation.mutate({
      id: jobId,
      title: title.trim(),
      description: description.trim(),
      requirements: requirements.trim() || undefined,
      company: company.trim(),
      city: city.trim(),
      salaryFrom: salaryFrom ? Number(salaryFrom) : undefined,
      salaryTo: salaryTo ? Number(salaryTo) : undefined,
      employmentType,
      professionId: Number(professionId),
      status,
    });
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container max-w-2xl">
        <button
          onClick={() => navigate("/dashboard/employer")}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          В кабинет работодателя
        </button>

        <h1 className="text-2xl font-bold text-foreground mb-6">Редактировать вакансию</h1>

        <div className="space-y-5">
          {/* Basic Info */}
          <div className="bg-card rounded-2xl border border-border p-6 space-y-4">
            <h2 className="font-semibold text-foreground">Основная информация</h2>
            <div>
              <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Название вакансии *</label>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Промышленный маляр" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Компания *</label>
              <Input value={company} onChange={(e) => setCompany(e.target.value)} placeholder="ООО Промстрой" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Город *</label>
                <Input value={city} onChange={(e) => setCity(e.target.value)} placeholder="Москва" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Профессия *</label>
                <Select value={professionId} onValueChange={setProfessionId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Выберите профессию" />
                  </SelectTrigger>
                  <SelectContent>
                    {professions?.map((p) => (
                      <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Зарплата от (₽)</label>
                <Input type="number" value={salaryFrom} onChange={(e) => setSalaryFrom(e.target.value)} placeholder="60000" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Зарплата до (₽)</label>
                <Input type="number" value={salaryTo} onChange={(e) => setSalaryTo(e.target.value)} placeholder="100000" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Тип занятости</label>
                <Select value={employmentType} onValueChange={(v) => setEmploymentType(v as typeof employmentType)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="полная">Полная</SelectItem>
                    <SelectItem value="частичная">Частичная</SelectItem>
                    <SelectItem value="вахта">Вахта</SelectItem>
                    <SelectItem value="договор">По договору</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="bg-card rounded-2xl border border-border p-6 space-y-4">
            <h2 className="font-semibold text-foreground">Описание</h2>
            <div>
              <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Описание вакансии *</label>
              <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={5} className="resize-none" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Требования</label>
              <Textarea value={requirements} onChange={(e) => setRequirements(e.target.value)} rows={4} className="resize-none" placeholder="Опыт работы, навыки, документы..." />
            </div>
          </div>

          {/* Status */}
          <div className="bg-card rounded-2xl border border-border p-6">
            <h2 className="font-semibold text-foreground mb-4">Статус вакансии</h2>
            <Select value={status} onValueChange={(v) => setStatus(v as typeof status)}>
              <SelectTrigger className="max-w-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="активна">Активна</SelectItem>
                <SelectItem value="черновик">Черновик</SelectItem>
                <SelectItem value="закрыта">Закрыта</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-3">
            <Button variant="outline" onClick={() => navigate("/dashboard/employer")} className="flex-1">
              Отмена
            </Button>
            <Button onClick={handleSubmit} disabled={updateMutation.isPending} className="flex-1">
              {updateMutation.isPending ? "Сохранение..." : "Сохранить изменения"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
