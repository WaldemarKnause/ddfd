import { useState, useEffect } from "react";
import { useLocation, useSearch } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import JobCard from "@/components/JobCard";
import { Search, MapPin, Briefcase, SlidersHorizontal, X } from "lucide-react";
import { Slider } from "@/components/ui/slider";

const ITEMS_PER_PAGE = 20;

export default function Jobs() {
  const searchStr = useSearch();
  const [, navigate] = useLocation();
  const params = new URLSearchParams(searchStr);

  const [search, setSearch] = useState(params.get("search") || "");
  const [professionId, setProfessionId] = useState(params.get("professionId") || "");
  const [city, setCity] = useState(params.get("city") || "");
  const [employmentType, setEmploymentType] = useState(params.get("employmentType") || "");
  const [page, setPage] = useState(1);
  const [showFilters, setShowFilters] = useState(false);
  const [salaryRange, setSalaryRange] = useState<[number, number]>([0, 300000]);

  const { data: professions } = trpc.professions.list.useQuery();

  const { data, isLoading } = trpc.jobs.list.useQuery({
    search: search || undefined,
    professionId: professionId && professionId !== "all" ? Number(professionId) : undefined,
    city: city || undefined,
    employmentType: employmentType && employmentType !== "all" ? employmentType : undefined,
    salaryMin: salaryRange[0] > 0 ? salaryRange[0] : undefined,
    salaryMax: salaryRange[1] < 300000 ? salaryRange[1] : undefined,
    page,
    limit: ITEMS_PER_PAGE,
  });

  const totalPages = data ? Math.ceil(data.total / ITEMS_PER_PAGE) : 0;

  const applyFilters = () => {
    setPage(1);
    const p = new URLSearchParams();
    if (search) p.set("search", search);
    if (professionId && professionId !== "all") p.set("professionId", professionId);
    if (city) p.set("city", city);
    if (employmentType && employmentType !== "all") p.set("employmentType", employmentType);
    navigate(`/jobs?${p.toString()}`);
  };

  const clearFilters = () => {
    setSearch("");
    setProfessionId("");
    setCity("");
    setEmploymentType("");
    setPage(1);
    navigate("/jobs");
  };

  const hasFilters = search || (professionId && professionId !== "all") || city || (employmentType && employmentType !== "all");

  return (
    <div className="min-h-screen py-8">
      <div className="container">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Вакансии</h1>
          <p className="text-muted-foreground mt-1">
            {data ? `Найдено ${data.total} вакансий` : "Загрузка..."}
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar Filters */}
          <aside className={`lg:w-72 flex-shrink-0 ${showFilters ? "block" : "hidden lg:block"}`}>
            <div className="bg-card rounded-2xl border border-border p-5 sticky top-24">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold text-foreground">Фильтры</h2>
                {hasFilters && (
                  <button
                    onClick={clearFilters}
                    className="text-xs text-muted-foreground hover:text-destructive transition-colors flex items-center gap-1"
                  >
                    <X className="w-3 h-3" />
                    Сбросить
                  </button>
                )}
              </div>

              <div className="space-y-4">
                {/* Search */}
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                    Поиск
                  </label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && applyFilters()}
                      placeholder="Должность, компания..."
                      className="pl-9"
                    />
                  </div>
                </div>

                {/* Profession */}
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                    Профессия
                  </label>
                  <Select value={professionId || "all"} onValueChange={setProfessionId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Все профессии" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Все профессии</SelectItem>
                      {professions?.map((p) => (
                        <SelectItem key={p.id} value={String(p.id)}>
                          {p.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* City */}
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                    Город
                  </label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && applyFilters()}
                      placeholder="Любой город"
                      className="pl-9"
                    />
                  </div>
                </div>

                {/* Employment Type */}
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                    Тип занятости
                  </label>
                  <Select value={employmentType || "all"} onValueChange={setEmploymentType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Любой тип" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Любой тип</SelectItem>
                      <SelectItem value="полная">Полная занятость</SelectItem>
                      <SelectItem value="частичная">Частичная занятость</SelectItem>
                      <SelectItem value="вахта">Вахтовый метод</SelectItem>
                      <SelectItem value="договор">По договору</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Salary Range */}
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                    Зарплата, ₽
                  </label>
                  <div className="px-1 pt-2 pb-1">
                    <Slider
                      min={0}
                      max={300000}
                      step={5000}
                      value={salaryRange}
                      onValueChange={(v) => setSalaryRange(v as [number, number])}
                      className="mb-3"
                    />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>{salaryRange[0] === 0 ? "от 0" : `от ${salaryRange[0].toLocaleString("ru")}`}</span>
                      <span>{salaryRange[1] >= 300000 ? "до ∞" : `до ${salaryRange[1].toLocaleString("ru")}`}</span>
                    </div>
                  </div>
                </div>

                <Button onClick={applyFilters} className="w-full">
                  Применить фильтры
                </Button>
              </div>
            </div>
          </aside>

          {/* Main Content */}
          <div className="flex-1 min-w-0">
            {/* Mobile filter toggle */}
            <div className="flex items-center gap-3 mb-4 lg:hidden">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center gap-2"
              >
                <SlidersHorizontal className="w-4 h-4" />
                Фильтры
                {hasFilters && (
                  <span className="w-2 h-2 rounded-full bg-primary" />
                )}
              </Button>
              {hasFilters && (
                <button onClick={clearFilters} className="text-sm text-muted-foreground hover:text-destructive flex items-center gap-1">
                  <X className="w-3 h-3" />
                  Сбросить
                </button>
              )}
            </div>

            {isLoading ? (
              <div className="space-y-3">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="bg-card rounded-2xl border border-border p-5 animate-pulse">
                    <div className="flex gap-3">
                      <div className="w-10 h-10 bg-muted rounded-xl" />
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-muted rounded w-3/4" />
                        <div className="h-3 bg-muted rounded w-1/2" />
                        <div className="h-3 bg-muted rounded w-2/3" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : data?.items.length === 0 ? (
              <div className="text-center py-20 bg-card rounded-2xl border border-border">
                <Briefcase className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-30" />
                <h3 className="font-semibold text-foreground mb-2">Вакансии не найдены</h3>
                <p className="text-muted-foreground text-sm mb-4">Попробуйте изменить параметры поиска</p>
                <Button variant="outline" onClick={clearFilters}>Сбросить фильтры</Button>
              </div>
            ) : (
              <>
                <div className="space-y-3">
                  {data?.items.map((job) => (
                    <JobCard key={job.id} {...job} />
                  ))}
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-center gap-2 mt-8">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPage(Math.max(1, page - 1))}
                      disabled={page === 1}
                    >
                      ←
                    </Button>

                    {Array.from({ length: Math.min(7, totalPages) }, (_, i) => {
                      let p: number;
                      if (totalPages <= 7) {
                        p = i + 1;
                      } else if (page <= 4) {
                        p = i + 1;
                      } else if (page >= totalPages - 3) {
                        p = totalPages - 6 + i;
                      } else {
                        p = page - 3 + i;
                      }
                      return (
                        <Button
                          key={p}
                          variant={p === page ? "default" : "outline"}
                          size="sm"
                          onClick={() => setPage(p)}
                          className="w-9 h-9 p-0"
                        >
                          {p}
                        </Button>
                      );
                    })}

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPage(Math.min(totalPages, page + 1))}
                      disabled={page === totalPages}
                    >
                      →
                    </Button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
