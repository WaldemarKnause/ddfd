import { useState, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { MapView } from "@/components/Map";
import { Link } from "wouter";
import { MapPin, Briefcase, X, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const EMPLOYMENT_COLORS: Record<string, string> = {
  "полная": "#3b82f6",
  "частичная": "#8b5cf6",
  "вахта": "#f59e0b",
  "договор": "#10b981",
};

const SALARY_LABEL = (from?: number | null, to?: number | null) => {
  if (!from && !to) return "Зарплата не указана";
  if (from && to) return `${from.toLocaleString("ru")} – ${to.toLocaleString("ru")} ₽`;
  if (from) return `от ${from.toLocaleString("ru")} ₽`;
  return `до ${to!.toLocaleString("ru")} ₽`;
};

export default function JobsMap() {
  const [selectedJob, setSelectedJob] = useState<number | null>(null);
  const { data } = trpc.jobs.list.useQuery({ limit: 200, page: 1 });

  const handleMapReady = useCallback(
    (map: google.maps.Map) => {
      if (!data?.items.length) return;

      const geocoder = new google.maps.Geocoder();
      const infoWindow = new google.maps.InfoWindow();

      data.items.forEach((job) => {
        geocoder.geocode({ address: `${job.city}, Россия` }, (results, status) => {
          if (status !== "OK" || !results?.[0]) return;

          const position = results[0].geometry.location;
          const color = EMPLOYMENT_COLORS[job.employmentType] ?? "#6366f1";

          const marker = new google.maps.Marker({
            position,
            map,
            title: job.title,
            icon: {
              path: google.maps.SymbolPath.CIRCLE,
              fillColor: color,
              fillOpacity: 0.9,
              strokeColor: "#fff",
              strokeWeight: 2,
              scale: 10,
            },
          });

          marker.addListener("click", () => {
            setSelectedJob(job.id);
            infoWindow.setContent(`
              <div style="font-family: sans-serif; padding: 4px; max-width: 220px;">
                <div style="font-weight: 700; font-size: 14px; margin-bottom: 4px;">${job.title}</div>
                <div style="color: #6b7280; font-size: 12px; margin-bottom: 4px;">${job.company} · ${job.city}</div>
                <div style="font-size: 12px; color: #111827;">${SALARY_LABEL(job.salaryFrom, job.salaryTo)}</div>
              </div>
            `);
            infoWindow.open(map, marker);
          });
        });
      });
    },
    [data]
  );

  const selectedJobData = selectedJob ? data?.items.find((j) => j.id === selectedJob) : null;

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <div className="container py-6">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Карта вакансий</h1>
            <p className="text-muted-foreground text-sm mt-1">
              {data ? `${data.total} вакансий на карте` : "Загрузка..."}
            </p>
          </div>
          <Button asChild variant="outline" size="sm">
            <Link href="/jobs">
              <Briefcase className="w-4 h-4 mr-2" />
              Список вакансий
            </Link>
          </Button>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-3 mt-3">
          {Object.entries(EMPLOYMENT_COLORS).map(([type, color]) => (
            <div key={type} className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: color }} />
              {type.charAt(0).toUpperCase() + type.slice(1)}
            </div>
          ))}
        </div>
      </div>

      {/* Map */}
      <div className="flex-1 relative" style={{ minHeight: "calc(100vh - 200px)" }}>
        <MapView
          onMapReady={handleMapReady}
          className="w-full h-full"
          initialCenter={{ lat: 55.7558, lng: 37.6173 }}
          initialZoom={5}
        />

        {/* Selected job panel */}
        {selectedJobData && (
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-full max-w-sm px-4">
            <div className="bg-card border border-border rounded-2xl shadow-xl p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-foreground text-sm truncate">{selectedJobData.title}</h3>
                  <p className="text-muted-foreground text-xs mt-0.5">{selectedJobData.company}</p>
                  <div className="flex items-center gap-1.5 mt-2">
                    <MapPin className="w-3 h-3 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{selectedJobData.city}</span>
                    <Badge variant="secondary" className="text-xs ml-1">
                      {selectedJobData.employmentType}
                    </Badge>
                  </div>
                  <p className="text-sm font-medium text-primary mt-2">
                    {SALARY_LABEL(selectedJobData.salaryFrom, selectedJobData.salaryTo)}
                  </p>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <button
                    onClick={() => setSelectedJob(null)}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    <X className="w-4 h-4" />
                  </button>
                  <Button asChild size="sm" className="mt-auto">
                    <Link href={`/jobs/${selectedJobData.id}`}>
                      <ChevronRight className="w-4 h-4" />
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
