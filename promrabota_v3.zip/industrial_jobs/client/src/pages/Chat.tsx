import { useState, useRef, useEffect } from "react";
import { useParams, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Send, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { ru } from "date-fns/locale";

export default function Chat() {
  const { id } = useParams<{ id: string }>();
  const applicationId = Number(id);
  const { user } = useAuth();
  const [text, setText] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const utils = trpc.useUtils();

  const { data: messages, isLoading } = trpc.chat.messages.useQuery(
    { applicationId },
    { refetchInterval: 3000 }
  );

  const sendMutation = trpc.chat.send.useMutation({
    onSuccess: () => {
      setText("");
      utils.chat.messages.invalidate({ applicationId });
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 100);
    },
    onError: () => toast.error("Не удалось отправить сообщение"),
  });

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!text.trim()) return;
    sendMutation.mutate({ applicationId, text: text.trim() });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card sticky top-0 z-10">
        <div className="container py-4 flex items-center gap-3">
          <Button variant="ghost" size="icon" asChild>
            <Link href={user?.role === "работодатель" ? "/dashboard/employer" : "/dashboard/seeker"}>
              <ArrowLeft className="w-4 h-4" />
            </Link>
          </Button>
          <div>
            <h1 className="font-semibold text-foreground">Чат по отклику #{applicationId}</h1>
            <p className="text-xs text-muted-foreground">Сообщения обновляются каждые 3 секунды</p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto">
        <div className="container py-6 max-w-2xl space-y-4">
          {isLoading && (
            <div className="flex justify-center py-12">
              <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          )}

          {!isLoading && messages?.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">Сообщений пока нет. Начните диалог!</p>
            </div>
          )}

          {messages?.map((msg) => {
            const isOwn = msg.senderId === user?.id;
            return (
              <div key={msg.id} className={`flex ${isOwn ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[75%] rounded-2xl px-4 py-3 ${
                    isOwn
                      ? "bg-primary text-primary-foreground rounded-br-sm"
                      : "bg-card border border-border text-foreground rounded-bl-sm"
                  }`}
                >
                  {!isOwn && (
                    <p className="text-xs font-medium mb-1 opacity-70">{msg.senderName ?? "Пользователь"}</p>
                  )}
                  <p className="text-sm whitespace-pre-wrap break-words">{msg.text}</p>
                  <p className={`text-xs mt-1.5 ${isOwn ? "text-primary-foreground/60" : "text-muted-foreground"}`}>
                    {format(new Date(msg.createdAt), "HH:mm, d MMM", { locale: ru })}
                  </p>
                </div>
              </div>
            );
          })}
          <div ref={bottomRef} />
        </div>
      </div>

      {/* Input */}
      <div className="border-t border-border bg-card sticky bottom-0">
        <div className="container py-4 max-w-2xl">
          <div className="flex gap-3 items-end">
            <Textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Введите сообщение... (Enter — отправить, Shift+Enter — новая строка)"
              className="resize-none min-h-[44px] max-h-[120px] bg-background"
              rows={1}
            />
            <Button
              onClick={handleSend}
              disabled={!text.trim() || sendMutation.isPending}
              size="icon"
              className="shrink-0"
            >
              {sendMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
