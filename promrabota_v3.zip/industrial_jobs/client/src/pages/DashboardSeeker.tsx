import { useState, useRef } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  User,
  Briefcase,
  Bookmark,
  FileText,
  Upload,
  MapPin,
  Phone,
  CheckCircle2,
  Clock,
  XCircle,
  Eye,
  MessageSquare,
} from "lucide-react";
import { toast } from "sonner";
import JobCard from "@/components/JobCard";

const statusConfig = {
  "новый": { label: "Новый", color: "bg-blue-500/10 text-blue-500 dark:bg-blue-400/15 dark:text-blue-400", icon: Clock },
  "просмотрен": { label: "Просмотрен", color: "bg-yellow-500/10 text-yellow-600 dark:bg-yellow-400/15 dark:text-yellow-400", icon: Eye },
  "приглашён": { label: "Приглашён", color: "bg-green-500/10 text-green-600 dark:bg-green-400/15 dark:text-green-400", icon: CheckCircle2 },
  "отказ": { label: "Отказ", color: "bg-red-500/10 text-red-600 dark:bg-red-400/15 dark:text-red-400", icon: XCircle },
};

export default function DashboardSeeker() {
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);

  const { data: profile } = trpc.seeker.profile.useQuery();
  const { data: applications } = trpc.applications.myApplications.useQuery();
  const { data: savedJobs } = trpc.savedJobs.list.useQuery();
  const { data: professions } = trpc.professions.list.useQuery();

  const [phone, setPhone] = useState(profile?.phone || "");
  const [city, setCity] = useState(profile?.city || "");
  const [bio, setBio] = useState(profile?.bio || "");
  const [professionId, setProfessionId] = useState(profile?.professionId ? String(profile.professionId) : "");

  const updateProfileMutation = trpc.seeker.updateProfile.useMutation({
    onSuccess: () => {
      toast.success("Профиль обновлён");
      utils.seeker.profile.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const uploadResumeMutation = trpc.seeker.uploadResume.useMutation({
    onSuccess: () => {
      toast.success("Резюме загружено");
      utils.seeker.profile.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const uploadPhotoMutation = trpc.seeker.uploadPhoto.useMutation({
    onSuccess: () => {
      toast.success("Фото загружено");
      utils.seeker.profile.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const handleFileUpload = async (file: File, type: "resume" | "photo") => {
    if (file.size > 10 * 1024 * 1024) {
      toast.error("Файл слишком большой. Максимум 10 МБ");
      return;
    }
    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64 = (e.target?.result as string).split(",")[1];
      if (type === "resume") {
        uploadResumeMutation.mutate({ fileName: file.name, fileBase64: base64, mimeType: file.type });
      } else {
        uploadPhotoMutation.mutate({ fileName: file.name, fileBase64: base64, mimeType: file.type });
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container max-w-5xl">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-foreground">Личный кабинет</h1>
          <p className="text-muted-foreground mt-1">Соискатель · {user?.name || user?.email}</p>
        </div>

        <Tabs defaultValue="applications">
          <TabsList className="mb-6">
            <TabsTrigger value="applications" className="flex items-center gap-2">
              <Briefcase className="w-4 h-4" />
              Мои отклики
              {applications && applications.length > 0 && (
                <Badge variant="secondary" className="ml-1 text-xs">{applications.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="saved" className="flex items-center gap-2">
              <Bookmark className="w-4 h-4" />
              Сохранённые
              {savedJobs && savedJobs.length > 0 && (
                <Badge variant="secondary" className="ml-1 text-xs">{savedJobs.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="profile" className="flex items-center gap-2">
              <User className="w-4 h-4" />
              Профиль
            </TabsTrigger>
          </TabsList>

          {/* Applications */}
          <TabsContent value="applications">
            {!applications || applications.length === 0 ? (
              <div className="text-center py-16 bg-card rounded-2xl border border-border">
                <Briefcase className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-30" />
                <h3 className="font-semibold text-foreground mb-2">Откликов пока нет</h3>
                <p className="text-muted-foreground text-sm mb-4">Найдите подходящую вакансию и откликнитесь</p>
                <Button asChild>
                  <Link href="/jobs">Смотреть вакансии</Link>
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {applications.map((app) => {
                  const status = statusConfig[app.status as keyof typeof statusConfig];
                  const StatusIcon = status?.icon || Clock;
                  return (
                    <div key={app.id} className="bg-card rounded-2xl border border-border p-5">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <Link href={`/jobs/${app.jobId}`} className="font-semibold text-foreground hover:text-primary transition-colors">
                            {app.jobTitle}
                          </Link>
                          <p className="text-sm text-muted-foreground mt-0.5">
                            {app.company} · {app.city}
                          </p>
                          {app.coverLetter && (
                            <p className="text-sm text-muted-foreground mt-2 line-clamp-2 italic">
                              "{app.coverLetter}"
                            </p>
                          )}
                        </div>
                        <div className={`flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-full flex-shrink-0 ${status?.color}`}>
                          <StatusIcon className="w-3.5 h-3.5" />
                          {status?.label}
                        </div>
                      </div>
                      <div className="flex items-center justify-between mt-3">
                        <p className="text-xs text-muted-foreground">
                          Отправлен {new Date(app.createdAt).toLocaleDateString("ru-RU")}
                        </p>
                        <Link href={`/chat/${app.id}`}>
                          <Button variant="outline" size="sm" className="text-xs h-7 gap-1.5">
                            <MessageSquare className="w-3.5 h-3.5" />
                            Чат
                          </Button>
                        </Link>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </TabsContent>

          {/* Saved Jobs */}
          <TabsContent value="saved">
            {!savedJobs || savedJobs.length === 0 ? (
              <div className="text-center py-16 bg-card rounded-2xl border border-border">
                <Bookmark className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-30" />
                <h3 className="font-semibold text-foreground mb-2">Сохранённых вакансий нет</h3>
                <p className="text-muted-foreground text-sm mb-4">Сохраняйте интересные вакансии, чтобы вернуться к ним позже</p>
                <Button asChild>
                  <Link href="/jobs">Смотреть вакансии</Link>
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {savedJobs.map((saved) => (
                  <JobCard
                    key={saved.id}
                    id={saved.jobId}
                    title={saved.jobTitle || ""}
                    company={saved.company || ""}
                    city={saved.city || ""}
                    salaryFrom={saved.salaryFrom}
                    salaryTo={saved.salaryTo}
                    currency={saved.currency || "₽"}
                    employmentType={saved.employmentType || "полная"}
                    professionName={saved.professionName}
                    createdAt={saved.createdAt}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          {/* Profile */}
          <TabsContent value="profile">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Profile Form */}
              <div className="bg-card rounded-2xl border border-border p-6">
                <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                  <User className="w-4 h-4" />
                  Личные данные
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Имя</label>
                    <Input value={user?.name || ""} disabled className="bg-muted" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Email</label>
                    <Input value={user?.email || ""} disabled className="bg-muted" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                      <Phone className="w-3.5 h-3.5 inline mr-1" />
                      Телефон
                    </label>
                    <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+7 (999) 000-00-00" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                      <MapPin className="w-3.5 h-3.5 inline mr-1" />
                      Город
                    </label>
                    <Input value={city} onChange={(e) => setCity(e.target.value)} placeholder="Ваш город" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Профессия</label>
                    <Select value={professionId || "none"} onValueChange={setProfessionId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Выберите профессию" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">Не указана</SelectItem>
                        {professions?.map((p) => (
                          <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">О себе</label>
                    <Textarea
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      placeholder="Расскажите о своём опыте..."
                      rows={3}
                      className="resize-none"
                    />
                  </div>
                  <Button
                    onClick={() => updateProfileMutation.mutate({
                      phone: phone || undefined,
                      city: city || undefined,
                      bio: bio || undefined,
                      professionId: professionId && professionId !== "none" ? Number(professionId) : undefined,
                    })}
                    disabled={updateProfileMutation.isPending}
                    className="w-full"
                  >
                    Сохранить
                  </Button>
                </div>
              </div>

              {/* Files */}
              <div className="space-y-4">
                {/* Resume */}
                <div className="bg-card rounded-2xl border border-border p-6">
                  <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    Резюме (PDF)
                  </h3>
                  {profile?.resumeUrl ? (
                    <div className="flex items-center gap-3 p-3 bg-accent rounded-xl mb-3">
                      <FileText className="w-5 h-5 text-primary" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">Резюме загружено</p>
                        <a href={profile.resumeUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline">
                          Открыть файл
                        </a>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground mb-3">Резюме не загружено</p>
                  )}
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileUpload(file, "resume");
                    }}
                  />
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploadResumeMutation.isPending}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    {uploadResumeMutation.isPending ? "Загрузка..." : "Загрузить PDF"}
                  </Button>
                </div>

                {/* Photo */}
                <div className="bg-card rounded-2xl border border-border p-6">
                  <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Фото профиля
                  </h3>
                  {profile?.photoUrl ? (
                    <div className="flex items-center gap-3 mb-3">
                      <img
                        src={profile.photoUrl}
                        alt="Фото профиля"
                        className="w-16 h-16 rounded-xl object-cover border border-border"
                      />
                      <p className="text-sm text-muted-foreground">Фото загружено</p>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground mb-3">Фото не загружено</p>
                  )}
                  <input
                    ref={photoInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileUpload(file, "photo");
                    }}
                  />
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => photoInputRef.current?.click()}
                    disabled={uploadPhotoMutation.isPending}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    {uploadPhotoMutation.isPending ? "Загрузка..." : "Загрузить фото"}
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
