import { useState } from "react";
import { useParams, useLocation, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  MapPin,
  Briefcase,
  Clock,
  Building2,
  ArrowLeft,
  Bookmark,
  BookmarkCheck,
  Send,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
import { toast } from "sonner";

function formatSalary(from?: number | null, to?: number | null, currency = "₽") {
  if (!from && !to) return null;
  if (from && to) return `${from.toLocaleString("ru")} – ${to.toLocaleString("ru")} ${currency}`;
  if (from) return `от ${from.toLocaleString("ru")} ${currency}`;
  if (to) return `до ${to.toLocaleString("ru")} ${currency}`;
  return null;
}

export default function JobDetail() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const utils = trpc.useUtils();

  const [applyOpen, setApplyOpen] = useState(false);
  const [coverLetter, setCoverLetter] = useState("");

  const { data: job, isLoading } = trpc.jobs.byId.useQuery({ id: Number(id) });
  const { data: existingApp } = trpc.applications.checkApplied.useQuery(
    { jobId: Number(id) },
    { enabled: isAuthenticated && user?.role === "соискатель" }
  );
  const { data: isSaved, refetch: refetchSaved } = trpc.savedJobs.isSaved.useQuery(
    { jobId: Number(id) },
    { enabled: isAuthenticated }
  );

  const submitMutation = trpc.applications.submit.useMutation({
    onSuccess: () => {
      toast.success("Отклик отправлен! Работодатель получит уведомление.");
      setApplyOpen(false);
      setCoverLetter("");
      utils.applications.checkApplied.invalidate({ jobId: Number(id) });
    },
    onError: (err) => {
      toast.error(err.message || "Ошибка при отправке отклика");
    },
  });

  const toggleSaveMutation = trpc.savedJobs.toggle.useMutation({
    onSuccess: (data) => {
      toast.success(data.saved ? "Вакансия сохранена" : "Вакансия удалена из сохранённых");
      refetchSaved();
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen py-8">
        <div className="container max-w-4xl">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-muted rounded w-1/3" />
            <div className="h-48 bg-muted rounded-2xl" />
            <div className="h-64 bg-muted rounded-2xl" />
          </div>
        </div>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="min-h-screen py-8">
        <div className="container max-w-4xl text-center py-20">
          <AlertCircle className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
          <h2 className="text-xl font-semibold mb-2">Вакансия не найдена</h2>
          <Button onClick={() => navigate("/jobs")} variant="outline">
            Вернуться к вакансиям
          </Button>
        </div>
      </div>
    );
  }

  const salary = formatSalary(job.salaryFrom, job.salaryTo, job.currency);
  const alreadyApplied = !!existingApp;
  const canApply = isAuthenticated && user?.role === "соискатель" && !alreadyApplied;

  return (
    <div className="min-h-screen py-8">
      <div className="container max-w-4xl">
        {/* Back */}
        <button
          onClick={() => navigate("/jobs")}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Назад к вакансиям
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-4">
            {/* Job Header */}
            <div className="bg-card rounded-2xl border border-border p-6">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-14 h-14 rounded-2xl bg-accent flex items-center justify-center text-primary font-bold text-xl flex-shrink-0">
                  {job.company.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <h1 className="text-2xl font-bold text-foreground leading-tight mb-1">{job.title}</h1>
                  <p className="text-muted-foreground font-medium">{job.company}</p>
                </div>
              </div>

              <div className="flex flex-wrap gap-3 mb-4">
                {salary && (
                  <div className="flex items-center gap-1.5 text-sm font-semibold text-foreground bg-accent rounded-lg px-3 py-1.5">
                    💰 {salary}
                  </div>
                )}
                <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                  <MapPin className="w-4 h-4" />
                  {job.city}
                </div>
                <Badge variant="outline" className="text-sm">
                  {job.employmentType}
                </Badge>
                {job.professionName && (
                  <Badge variant="outline" className="text-sm bg-secondary text-secondary-foreground border-secondary">
                    {job.professionName}
                  </Badge>
                )}
              </div>

              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Clock className="w-3.5 h-3.5" />
                Опубликовано {new Date(job.createdAt).toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" })}
              </div>
            </div>

            {/* Description */}
            <div className="bg-card rounded-2xl border border-border p-6">
              <h2 className="text-lg font-semibold text-foreground mb-4">Описание вакансии</h2>
              <div className="prose prose-sm max-w-none text-foreground/80 whitespace-pre-wrap leading-relaxed">
                {job.description}
              </div>
            </div>

            {/* Requirements */}
            {job.requirements && (
              <div className="bg-card rounded-2xl border border-border p-6">
                <h2 className="text-lg font-semibold text-foreground mb-4">Требования</h2>
                <div className="prose prose-sm max-w-none text-foreground/80 whitespace-pre-wrap leading-relaxed">
                  {job.requirements}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Apply Card */}
            <div className="bg-card rounded-2xl border border-border p-5 sticky top-24">
              <div className="space-y-3">
                {/* Apply Button */}
                {isAuthenticated ? (
                  user?.role === "соискатель" ? (
                    alreadyApplied ? (
                      <div className="flex items-center gap-2 text-sm text-green-600 bg-green-50 rounded-xl p-3">
                        <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                        Вы уже откликнулись на эту вакансию
                      </div>
                    ) : (
                      <Button
                        onClick={() => setApplyOpen(true)}
                        className="w-full font-semibold"
                        size="lg"
                      >
                        <Send className="w-4 h-4 mr-2" />
                        Откликнуться
                      </Button>
                    )
                  ) : user?.role === "работодатель" ? (
                    <p className="text-sm text-muted-foreground text-center py-2">
                      Работодатели не могут откликаться на вакансии
                    </p>
                  ) : null
                ) : (
                  <Button asChild className="w-full font-semibold" size="lg">
                    <a href={getLoginUrl()}>
                      <Send className="w-4 h-4 mr-2" />
                      Войти и откликнуться
                    </a>
                  </Button>
                )}

                {/* Save Button */}
                {isAuthenticated && (
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => toggleSaveMutation.mutate({ jobId: Number(id) })}
                    disabled={toggleSaveMutation.isPending}
                  >
                    {isSaved ? (
                      <>
                        <BookmarkCheck className="w-4 h-4 mr-2 text-primary" />
                        Сохранено
                      </>
                    ) : (
                      <>
                        <Bookmark className="w-4 h-4 mr-2" />
                        Сохранить
                      </>
                    )}
                  </Button>
                )}
              </div>

              <div className="mt-4 pt-4 border-t border-border space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Building2 className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Компания:</span>
                  <span className="font-medium text-foreground">{job.company}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Город:</span>
                  <span className="font-medium text-foreground">{job.city}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Briefcase className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Занятость:</span>
                  <span className="font-medium text-foreground">{job.employmentType}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Apply Dialog */}
      <Dialog open={applyOpen} onOpenChange={setApplyOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Отклик на вакансию</DialogTitle>
            <DialogDescription>
              {job.title} — {job.company}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <label className="text-sm font-medium text-foreground">
              Сопроводительное письмо <span className="text-muted-foreground">(необязательно)</span>
            </label>
            <Textarea
              value={coverLetter}
              onChange={(e) => setCoverLetter(e.target.value)}
              placeholder="Расскажите о своём опыте и почему вас интересует эта вакансия..."
              rows={5}
              className="resize-none"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setApplyOpen(false)}>
              Отмена
            </Button>
            <Button
              onClick={() =>
                submitMutation.mutate({
                  jobId: Number(id),
                  coverLetter: coverLetter || undefined,
                })
              }
              disabled={submitMutation.isPending}
            >
              {submitMutation.isPending ? "Отправка..." : "Отправить отклик"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
