import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Briefcase } from "lucide-react";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";

export default function JobForm() {
  const [, navigate] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const utils = trpc.useUtils();

  const { data: professions } = trpc.professions.list.useQuery();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [requirements, setRequirements] = useState("");
  const [company, setCompany] = useState("");
  const [city, setCity] = useState("");
  const [salaryFrom, setSalaryFrom] = useState("");
  const [salaryTo, setSalaryTo] = useState("");
  const [employmentType, setEmploymentType] = useState<"полная" | "частичная" | "вахта" | "договор">("полная");
  const [professionId, setProfessionId] = useState("");
  const [status, setStatus] = useState<"активна" | "черновик">("активна");

  const createMutation = trpc.jobs.create.useMutation({
    onSuccess: () => {
      toast.success("Вакансия опубликована!");
      utils.jobs.myJobs.invalidate();
      navigate("/dashboard/employer");
    },
    onError: (err) => toast.error(err.message || "Ошибка при создании вакансии"),
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-4">Войдите, чтобы разместить вакансию</h2>
          <Button asChild>
            <a href={getLoginUrl()}>Войти</a>
          </Button>
        </div>
      </div>
    );
  }

  if (user?.role !== "работодатель" && user?.role !== "админ") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Только работодатели могут размещать вакансии</h2>
          <p className="text-muted-foreground mb-4">Смените роль в личном кабинете</p>
          <Button onClick={() => navigate("/dashboard/seeker")}>В личный кабинет</Button>
        </div>
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!professionId) {
      toast.error("Выберите профессию");
      return;
    }
    createMutation.mutate({
      title,
      description,
      requirements: requirements || undefined,
      company,
      city,
      salaryFrom: salaryFrom ? Number(salaryFrom) : undefined,
      salaryTo: salaryTo ? Number(salaryTo) : undefined,
      employmentType,
      professionId: Number(professionId),
      status,
    });
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container max-w-2xl">
        <button
          onClick={() => navigate("/dashboard/employer")}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Назад
        </button>

        <div className="mb-8">
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Briefcase className="w-6 h-6" />
            Разместить вакансию
          </h1>
          <p className="text-muted-foreground mt-1">Заполните информацию о вакансии</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-card rounded-2xl border border-border p-6 space-y-4">
            <h2 className="font-semibold text-foreground">Основная информация</h2>

            <div>
              <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                Название вакансии *
              </label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Маляр на промышленный объект"
                required
              />
            </div>

            <div>
              <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                Компания *
              </label>
              <Input
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                placeholder="ООО СтройПром"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                  Профессия *
                </label>
                <Select value={professionId} onValueChange={setProfessionId} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Выберите профессию" />
                  </SelectTrigger>
                  <SelectContent>
                    {professions?.map((p) => (
                      <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                  Тип занятости *
                </label>
                <Select value={employmentType} onValueChange={(v) => setEmploymentType(v as typeof employmentType)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="полная">Полная занятость</SelectItem>
                    <SelectItem value="частичная">Частичная занятость</SelectItem>
                    <SelectItem value="вахта">Вахтовый метод</SelectItem>
                    <SelectItem value="договор">По договору</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                Город *
              </label>
              <Input
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Москва"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                  Зарплата от (₽)
                </label>
                <Input
                  type="number"
                  value={salaryFrom}
                  onChange={(e) => setSalaryFrom(e.target.value)}
                  placeholder="80000"
                  min="0"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                  Зарплата до (₽)
                </label>
                <Input
                  type="number"
                  value={salaryTo}
                  onChange={(e) => setSalaryTo(e.target.value)}
                  placeholder="120000"
                  min="0"
                />
              </div>
            </div>
          </div>

          <div className="bg-card rounded-2xl border border-border p-6 space-y-4">
            <h2 className="font-semibold text-foreground">Описание</h2>

            <div>
              <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                Описание вакансии *
              </label>
              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Подробное описание обязанностей, условий работы..."
                rows={6}
                className="resize-none"
                required
              />
            </div>

            <div>
              <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                Требования
              </label>
              <Textarea
                value={requirements}
                onChange={(e) => setRequirements(e.target.value)}
                placeholder="Опыт работы, навыки, образование..."
                rows={4}
                className="resize-none"
              />
            </div>
          </div>

          <div className="bg-card rounded-2xl border border-border p-6">
            <div>
              <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                Статус публикации
              </label>
              <Select value={status} onValueChange={(v) => setStatus(v as typeof status)}>
                <SelectTrigger className="max-w-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="активна">Опубликовать сразу</SelectItem>
                  <SelectItem value="черновик">Сохранить как черновик</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex gap-3">
            <Button type="submit" disabled={createMutation.isPending} className="flex-1 font-semibold">
              {createMutation.isPending ? "Публикация..." : status === "активна" ? "Опубликовать вакансию" : "Сохранить черновик"}
            </Button>
            <Button type="button" variant="outline" onClick={() => navigate("/dashboard/employer")}>
              Отмена
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
