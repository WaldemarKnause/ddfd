import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Briefcase,
  Plus,
  Building2,
  Users,
  Pencil,
  Trash2,
  MapPin,
  Phone,
  Globe,
  FileText,
  Download,
  ExternalLink,
  MessageSquare,
} from "lucide-react";
import { toast } from "sonner";

const statusColors = {
  "активна": "bg-green-500/10 text-green-600 dark:bg-green-400/15 dark:text-green-400",
  "закрыта": "bg-muted text-muted-foreground",
  "черновик": "bg-yellow-500/10 text-yellow-600 dark:bg-yellow-400/15 dark:text-yellow-400",
};

const appStatusColors = {
  "новый": "bg-blue-500/10 text-blue-500 dark:bg-blue-400/15 dark:text-blue-400",
  "просмотрен": "bg-yellow-500/10 text-yellow-600 dark:bg-yellow-400/15 dark:text-yellow-400",
  "приглашён": "bg-green-500/10 text-green-600 dark:bg-green-400/15 dark:text-green-400",
  "отказ": "bg-red-500/10 text-red-600 dark:bg-red-400/15 dark:text-red-400",
};

export default function DashboardEmployer() {
  const { user } = useAuth();
  const utils = trpc.useUtils();

  const [activeTab, setActiveTab] = useState("jobs");
  const [selectedJobId, setSelectedJobId] = useState<number | null>(null);
  const [deleteJobId, setDeleteJobId] = useState<number | null>(null);
  const [viewSeekerId, setViewSeekerId] = useState<number | null>(null);
  const [exportLoading, setExportLoading] = useState(false);

  const { data: myJobs } = trpc.jobs.myJobs.useQuery({ page: 1 });
  const { data: profile } = trpc.employer.profile.useQuery();
  const { data: applications, isLoading: appsLoading } = trpc.applications.jobApplications.useQuery(
    { jobId: selectedJobId! },
    { enabled: !!selectedJobId }
  );
  const { data: seekerProfile } = trpc.seeker.getProfileByIdFull.useQuery(
    { userId: viewSeekerId! },
    { enabled: !!viewSeekerId }
  );

  const [companyName, setCompanyName] = useState(profile?.companyName || "");
  const [companyDesc, setCompanyDesc] = useState(profile?.companyDescription || "");
  const [website, setWebsite] = useState(profile?.website || "");
  const [phone, setPhone] = useState(profile?.phone || "");
  const [city, setCity] = useState(profile?.city || "");

  const updateProfileMutation = trpc.employer.updateProfile.useMutation({
    onSuccess: () => {
      toast.success("Профиль компании обновлён");
      utils.employer.profile.invalidate();
    },
  });

  const deleteJobMutation = trpc.jobs.delete.useMutation({
    onSuccess: () => {
      toast.success("Вакансия закрыта");
      utils.jobs.myJobs.invalidate();
      setDeleteJobId(null);
    },
  });

  const updateStatusMutation = trpc.applications.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Статус обновлён");
      utils.applications.jobApplications.invalidate({ jobId: selectedJobId! });
    },
  });

  const exportCsvMutation = trpc.export.applicationsCSV.useQuery(
    { jobId: selectedJobId ?? undefined },
    { enabled: false }
  );

  const handleExportCsv = async () => {
    setExportLoading(true);
    try {
      const result = await exportCsvMutation.refetch();
      if (result.data) {
        const rows = result.data as Array<Record<string, unknown>>;
        if (!rows.length) {
          toast.info("Нет данных для экспорта");
          return;
        }
        const headers = Object.keys(rows[0]);
        const csvContent = [
          headers.join(";"),
          ...rows.map((row) =>
            headers.map((h) => {
              const val = row[h];
              const str = val == null ? "" : String(val);
              return str.includes(";") || str.includes('"') || str.includes("\n")
                ? `"${str.replace(/"/g, '""')}"`
                : str;
            }).join(";")
          ),
        ].join("\n");

        const blob = new Blob(["\uFEFF" + csvContent], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `otkliki_${selectedJobId ? `vakansiya_${selectedJobId}` : "vse"}.csv`;
        a.click();
        URL.revokeObjectURL(url);
        toast.success("CSV-файл скачан");
      }
    } catch {
      toast.error("Ошибка экспорта");
    } finally {
      setExportLoading(false);
    }
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container max-w-5xl">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Кабинет работодателя</h1>
            <p className="text-muted-foreground mt-1">{user?.name || user?.email}</p>
          </div>
          <Button asChild>
            <Link href="/jobs/new">
              <Plus className="w-4 h-4 mr-2" />
              Разместить вакансию
            </Link>
          </Button>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="jobs" className="flex items-center gap-2">
              <Briefcase className="w-4 h-4" />
              Мои вакансии
              {myJobs && myJobs.total > 0 && (
                <Badge variant="secondary" className="ml-1 text-xs">{myJobs.total}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="applications" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Отклики
            </TabsTrigger>
            <TabsTrigger value="profile" className="flex items-center gap-2">
              <Building2 className="w-4 h-4" />
              Профиль компании
            </TabsTrigger>
          </TabsList>

          {/* My Jobs */}
          <TabsContent value="jobs">
            {!myJobs || myJobs.items.length === 0 ? (
              <div className="text-center py-16 bg-card rounded-2xl border border-border">
                <Briefcase className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-30" />
                <h3 className="font-semibold text-foreground mb-2">Вакансий пока нет</h3>
                <p className="text-muted-foreground text-sm mb-4">Разместите первую вакансию</p>
                <Button asChild>
                  <Link href="/jobs/new">Разместить вакансию</Link>
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {myJobs.items.map((job) => (
                  <div key={job.id} className="bg-card rounded-2xl border border-border p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Link href={`/jobs/${job.id}`} className="font-semibold text-foreground hover:text-primary transition-colors">
                            {job.title}
                          </Link>
                          <Badge className={`text-xs ${statusColors[job.status as keyof typeof statusColors]}`} variant="outline">
                            {job.status}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {job.city} · {job.employmentType}
                          {job.salaryFrom && ` · от ${job.salaryFrom.toLocaleString("ru")} ₽`}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Опубликована {new Date(job.createdAt).toLocaleDateString("ru-RU")}
                        </p>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setSelectedJobId(job.id);
                            setActiveTab("applications");
                          }}
                          className="text-muted-foreground hover:text-foreground text-xs gap-1"
                        >
                          <Users className="w-4 h-4" />
                          Отклики
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          asChild
                          className="text-muted-foreground hover:text-foreground"
                        >
                          <Link href={`/jobs/${job.id}/edit`}>
                            <Pencil className="w-4 h-4" />
                          </Link>
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setDeleteJobId(job.id)}
                          className="text-muted-foreground hover:text-destructive"
                          disabled={job.status === "закрыта"}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Applications */}
          <TabsContent value="applications">
            <div className="flex items-end gap-3 mb-4 flex-wrap">
              <div className="flex-1 min-w-[200px]">
                <label className="text-sm font-medium text-muted-foreground mb-2 block">Выберите вакансию:</label>
                <Select
                  value={selectedJobId ? String(selectedJobId) : ""}
                  onValueChange={(v) => setSelectedJobId(Number(v))}
                >
                  <SelectTrigger className="max-w-sm">
                    <SelectValue placeholder="Выберите вакансию" />
                  </SelectTrigger>
                  <SelectContent>
                    {myJobs?.items.map((job) => (
                      <SelectItem key={job.id} value={String(job.id)}>{job.title}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleExportCsv}
                disabled={exportLoading}
                className="flex items-center gap-2 shrink-0"
              >
                <Download className="w-4 h-4" />
                {exportLoading ? "Экспорт..." : "Экспорт CSV"}
              </Button>
            </div>

            {!selectedJobId ? (
              <div className="text-center py-12 bg-card rounded-2xl border border-border text-muted-foreground">
                Выберите вакансию для просмотра откликов
              </div>
            ) : appsLoading ? (
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="bg-card rounded-2xl border border-border p-5 animate-pulse h-24" />
                ))}
              </div>
            ) : !applications || applications.length === 0 ? (
              <div className="text-center py-12 bg-card rounded-2xl border border-border">
                <Users className="w-10 h-10 mx-auto mb-3 text-muted-foreground opacity-30" />
                <p className="text-muted-foreground">Откликов на эту вакансию пока нет</p>
              </div>
            ) : (
              <div className="space-y-3">
                {applications.map((app) => (
                  <div key={app.id} className="bg-card rounded-2xl border border-border p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-foreground">{app.seekerName || "Соискатель"}</p>
                        <p className="text-sm text-muted-foreground">{app.seekerEmail}</p>
                        {app.coverLetter && (
                          <p className="text-sm text-muted-foreground mt-2 italic line-clamp-2">
                            "{app.coverLetter}"
                          </p>
                        )}
                        <div className="flex items-center gap-3 mt-2 flex-wrap">
                          <p className="text-xs text-muted-foreground">
                            {new Date(app.createdAt).toLocaleDateString("ru-RU")}
                          </p>
                          {/* View seeker profile / files */}
                          <button
                            onClick={() => setViewSeekerId(app.seekerId)}
                            className="text-xs text-primary hover:underline flex items-center gap-1"
                          >
                            <ExternalLink className="w-3 h-3" />
                            Профиль и файлы
                          </button>
                          {/* Chat button */}
                          <Link href={`/chat/${app.id}`} className="text-xs text-primary hover:underline flex items-center gap-1">
                            <MessageSquare className="w-3 h-3" />
                            Чат
                          </Link>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge className={`text-xs ${appStatusColors[app.status as keyof typeof appStatusColors]}`} variant="outline">
                          {app.status}
                        </Badge>
                        <Select
                          value={app.status}
                          onValueChange={(v) => updateStatusMutation.mutate({
                            id: app.id,
                            status: v as "новый" | "просмотрен" | "приглашён" | "отказ",
                          })}
                        >
                          <SelectTrigger className="w-36 h-8 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="новый">Новый</SelectItem>
                            <SelectItem value="просмотрен">Просмотрен</SelectItem>
                            <SelectItem value="приглашён">Приглашён</SelectItem>
                            <SelectItem value="отказ">Отказ</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Company Profile */}
          <TabsContent value="profile">
            <div className="bg-card rounded-2xl border border-border p-6 max-w-xl">
              <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                <Building2 className="w-4 h-4" />
                Профиль компании
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">Название компании</label>
                  <Input value={companyName} onChange={(e) => setCompanyName(e.target.value)} placeholder="ООО Пример" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">О компании</label>
                  <Textarea value={companyDesc} onChange={(e) => setCompanyDesc(e.target.value)} placeholder="Расскажите о вашей компании..." rows={3} className="resize-none" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                    <Globe className="w-3.5 h-3.5 inline mr-1" />Сайт
                  </label>
                  <Input value={website} onChange={(e) => setWebsite(e.target.value)} placeholder="https://example.com" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                    <Phone className="w-3.5 h-3.5 inline mr-1" />Телефон
                  </label>
                  <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+7 (999) 000-00-00" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1.5 block">
                    <MapPin className="w-3.5 h-3.5 inline mr-1" />Город
                  </label>
                  <Input value={city} onChange={(e) => setCity(e.target.value)} placeholder="Москва" />
                </div>
                <Button
                  onClick={() => updateProfileMutation.mutate({
                    companyName: companyName || undefined,
                    companyDescription: companyDesc || undefined,
                    website: website || undefined,
                    phone: phone || undefined,
                    city: city || undefined,
                  })}
                  disabled={updateProfileMutation.isPending}
                  className="w-full"
                >
                  Сохранить
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Delete Confirmation */}
        <Dialog open={!!deleteJobId} onOpenChange={() => setDeleteJobId(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Закрыть вакансию?</DialogTitle>
            </DialogHeader>
            <p className="text-muted-foreground text-sm">Вакансия будет закрыта и не будет отображаться в каталоге.</p>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDeleteJobId(null)}>Отмена</Button>
              <Button
                variant="destructive"
                onClick={() => deleteJobId && deleteJobMutation.mutate({ id: deleteJobId })}
                disabled={deleteJobMutation.isPending}
              >
                Закрыть вакансию
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Seeker Profile Modal */}
        <Dialog open={!!viewSeekerId} onOpenChange={() => setViewSeekerId(null)}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Профиль соискателя</DialogTitle>
            </DialogHeader>
            {seekerProfile ? (
              <div className="space-y-4 py-2">
                <div className="flex items-center gap-4">
                  {seekerProfile.profile.photoUrl ? (
                    <img src={seekerProfile.profile.photoUrl} alt="Фото" className="w-16 h-16 rounded-xl object-cover border border-border" />
                  ) : (
                    <div className="w-16 h-16 rounded-xl bg-accent flex items-center justify-center text-primary font-bold text-xl">
                      {(seekerProfile.user?.name || "?").charAt(0).toUpperCase()}
                    </div>
                  )}
                  <div>
                    <p className="font-semibold text-foreground">{seekerProfile.user?.name || "—"}</p>
                    <p className="text-sm text-muted-foreground">{seekerProfile.user?.email || "—"}</p>
                    {seekerProfile.profile.phone && <p className="text-sm text-muted-foreground">{seekerProfile.profile.phone}</p>}
                    {seekerProfile.profile.city && <p className="text-sm text-muted-foreground">{seekerProfile.profile.city}</p>}
                  </div>
                </div>

                {seekerProfile.profile.bio && (
                  <div>
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1">О себе</p>
                    <p className="text-sm text-foreground/80">{seekerProfile.profile.bio}</p>
                  </div>
                )}

                <div className="space-y-2">
                  {seekerProfile.profile.resumeUrl && (
                    <a
                      href={seekerProfile.profile.resumeUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 p-3 rounded-xl bg-accent hover:bg-accent/80 transition-colors"
                    >
                      <FileText className="w-5 h-5 text-primary" />
                      <span className="text-sm font-medium text-foreground">Скачать резюме (PDF)</span>
                      <Download className="w-4 h-4 text-muted-foreground ml-auto" />
                    </a>
                  )}
                  {!seekerProfile.profile.resumeUrl && (
                    <p className="text-sm text-muted-foreground">Резюме не загружено</p>
                  )}
                </div>
              </div>
            ) : (
              <div className="py-8 text-center text-muted-foreground">Загрузка...</div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setViewSeekerId(null)}>Закрыть</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
