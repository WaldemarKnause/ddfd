import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Header from "./components/Header";
import Home from "./pages/Home";
import Jobs from "./pages/Jobs";
import JobDetail from "./pages/JobDetail";
import JobForm from "./pages/JobForm";
import DashboardSeeker from "./pages/DashboardSeeker";
import DashboardEmployer from "./pages/DashboardEmployer";
import Admin from "./pages/Admin";
import RoleSelect from "./pages/RoleSelect";
import JobEdit from "./pages/JobEdit";
import Login from "./pages/Login";
import Register from "./pages/Register";
import JobsMap from "./pages/JobsMap";
import Chat from "./pages/Chat";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/jobs" component={Jobs} />
      <Route path="/jobs/new" component={JobForm} />
      <Route path="/jobs/:id/edit" component={JobEdit} />
      <Route path="/jobs/:id" component={JobDetail} />
      <Route path="/dashboard/seeker" component={DashboardSeeker} />
      <Route path="/dashboard/employer" component={DashboardEmployer} />
      <Route path="/admin" component={Admin} />
      <Route path="/role-select" component={RoleSelect} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/map" component={JobsMap} />
      <Route path="/chat/:id" component={Chat} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark" switchable>
        <TooltipProvider>
          <Toaster />
          <div className="min-h-screen bg-background">
            <Header />
            <main>
              <Router />
            </main>
          </div>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
