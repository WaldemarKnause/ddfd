/**
 * Local email+password authentication routes
 * Mounted at /api/auth/local/*
 * Works alongside Manus OAuth — users can use either method.
 */
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import type { Express } from "express";
import { localAuth, users } from "../drizzle/schema";
import { getDb, getUserByOpenId } from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { sdk } from "./_core/sdk";
import { COOKIE_NAME } from "../shared/const";

const SALT_ROUNDS = 10;

/** Generate a deterministic local openId from email */
function localOpenId(email: string): string {
  return `local:${email.toLowerCase()}`;
}

export function registerLocalAuthRoutes(app: Express) {
  // POST /api/auth/local/register
  app.post("/api/auth/local/register", async (req, res) => {
    try {
      const { email, password, name } = req.body as {
        email?: string;
        password?: string;
        name?: string;
      };

      if (!email || !password) {
        return res.status(400).json({ error: "Email и пароль обязательны" });
      }
      if (password.length < 6) {
        return res.status(400).json({ error: "Пароль должен быть не менее 6 символов" });
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return res.status(400).json({ error: "Некорректный email" });
      }

      const db = await getDb();
      if (!db) return res.status(500).json({ error: "База данных недоступна" });

      // Check if email already registered
      const existing = await db
        .select()
        .from(localAuth)
        .where(eq(localAuth.email, email.toLowerCase()))
        .limit(1);

      if (existing.length > 0) {
        return res.status(409).json({ error: "Пользователь с таким email уже существует" });
      }

      const openId = localOpenId(email);
      const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

      // Create user
      await db.insert(users).values({
        openId,
        name: name || email.split("@")[0],
        email: email.toLowerCase(),
        loginMethod: "local",
        role: "соискатель",
        lastSignedIn: new Date(),
      });

      const newUser = await getUserByOpenId(openId);
      if (!newUser) return res.status(500).json({ error: "Ошибка создания пользователя" });

      // Save password hash
      await db.insert(localAuth).values({
        userId: newUser.id,
        email: email.toLowerCase(),
        passwordHash,
      });

      // Create session
      const token = await sdk.createSessionToken(openId, {
        name: newUser.name || "",
      });
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, token, cookieOptions);

      return res.json({
        success: true,
        user: {
          id: newUser.id,
          name: newUser.name,
          email: newUser.email,
          role: newUser.role,
        },
      });
    } catch (err) {
      console.error("[LocalAuth] Register error:", err);
      return res.status(500).json({ error: "Внутренняя ошибка сервера" });
    }
  });

  // POST /api/auth/local/login
  app.post("/api/auth/local/login", async (req, res) => {
    try {
      const { email, password } = req.body as {
        email?: string;
        password?: string;
      };

      if (!email || !password) {
        return res.status(400).json({ error: "Email и пароль обязательны" });
      }

      const db = await getDb();
      if (!db) return res.status(500).json({ error: "База данных недоступна" });

      const authRecord = await db
        .select()
        .from(localAuth)
        .where(eq(localAuth.email, email.toLowerCase()))
        .limit(1);

      if (authRecord.length === 0) {
        return res.status(401).json({ error: "Неверный email или пароль" });
      }

      const isValid = await bcrypt.compare(password, authRecord[0].passwordHash);
      if (!isValid) {
        return res.status(401).json({ error: "Неверный email или пароль" });
      }

      const openId = localOpenId(email);
      const user = await getUserByOpenId(openId);
      if (!user) return res.status(500).json({ error: "Пользователь не найден" });

      // Create session
      const token = await sdk.createSessionToken(openId, {
        name: user.name || "",
      });
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, token, cookieOptions);

      return res.json({
        success: true,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
        },
      });
    } catch (err) {
      console.error("[LocalAuth] Login error:", err);
      return res.status(500).json({ error: "Внутренняя ошибка сервера" });
    }
  });
}
