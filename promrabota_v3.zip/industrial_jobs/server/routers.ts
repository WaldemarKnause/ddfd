import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  checkExistingApplication,
  createApplication,
  createJob,
  createProfession,
  deleteJob,
  deleteProfession,
  getAllProfessions,
  getAllUsers,
  getApplicationById,
  getApplicationsByJob,
  getApplicationsBySeeker,
  getDb,
  getEmployerProfile,
  getJobById,
  getJobs,
  getProfessions,
  getSavedJobs,
  getSeekerProfile,
  getSeekerProfileWithUser,
  isSavedJob,
  toggleSavedJob,
  updateApplicationStatus,
  updateJob,
  updateProfession,
  updateUserRole,
  upsertEmployerProfile,
  upsertSeekerProfile,
  upsertUser,
  getChatMessages,
  sendChatMessage,
  getApplicationsForExport,
} from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { notifyOwner } from "./_core/notification";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { storagePut } from "./storage";
import { eq } from "drizzle-orm";
import { applications, jobs, users } from "../drizzle/schema";

// ─── Professions ─────────────────────────────────────────────────────────────

const professionsRouter = router({
  list: publicProcedure.query(() => getProfessions()),

  listAll: adminProcedure.query(() => getAllProfessions()),

  create: adminProcedure
    .input(
      z.object({
        name: z.string().min(2),
        slug: z.string().min(2),
        description: z.string().optional(),
      })
    )
    .mutation(({ input }) => createProfession({ ...input, isActive: true })),

  update: adminProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(2).optional(),
        slug: z.string().min(2).optional(),
        description: z.string().optional(),
        isActive: z.boolean().optional(),
      })
    )
    .mutation(({ input }) => {
      const { id, ...data } = input;
      return updateProfession(id, data);
    }),

  delete: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(({ input }) => deleteProfession(input.id)),
});

// ─── Jobs ─────────────────────────────────────────────────────────────────────

const jobsRouter = router({
  list: publicProcedure
    .input(
      z.object({
        search: z.string().optional(),
        professionId: z.number().optional(),
        city: z.string().optional(),
        employmentType: z.string().optional(),
        salaryMin: z.number().optional(),
        salaryMax: z.number().optional(),
        page: z.number().default(1),
        limit: z.number().default(20),
      })
    )
    .query(({ input }) => getJobs({ ...input, status: "активна" })),

  myJobs: protectedProcedure
    .input(z.object({ page: z.number().default(1) }))
    .query(({ ctx, input }) =>
      getJobs({ employerId: ctx.user.id, page: input.page, limit: 20, status: undefined })
    ),

  adminList: adminProcedure
    .input(
      z.object({
        page: z.number().default(1),
        status: z.string().optional(),
      })
    )
    .query(({ input }) => getJobs({ page: input.page, limit: 30, status: input.status })),

  byId: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      await incrementJobViews(input.id);
      return getJobById(input.id);
    }),

  create: protectedProcedure
    .input(
      z.object({
        title: z.string().min(3),
        description: z.string().min(10),
        requirements: z.string().optional(),
        company: z.string().min(2),
        city: z.string().min(2),
        salaryFrom: z.number().optional(),
        salaryTo: z.number().optional(),
        employmentType: z.enum(["полная", "частичная", "вахта", "договор"]),
        professionId: z.number(),
        status: z.enum(["активна", "черновик"]).default("активна"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "работодатель" && ctx.user.role !== "админ") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Только работодатели могут размещать вакансии" });
      }
      return createJob({ ...input, employerId: ctx.user.id });
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        title: z.string().min(3).optional(),
        description: z.string().min(10).optional(),
        requirements: z.string().optional(),
        company: z.string().min(2).optional(),
        city: z.string().min(2).optional(),
        salaryFrom: z.number().optional(),
        salaryTo: z.number().optional(),
        employmentType: z.enum(["полная", "частичная", "вахта", "договор"]).optional(),
        professionId: z.number().optional(),
        status: z.enum(["активна", "закрыта", "черновик"]).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const job = await getJobById(input.id);
      if (!job) throw new TRPCError({ code: "NOT_FOUND" });
      if (job.employerId !== ctx.user.id && ctx.user.role !== "админ") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      const { id, ...data } = input;
      return updateJob(id, data);
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const job = await getJobById(input.id);
      if (!job) throw new TRPCError({ code: "NOT_FOUND" });
      if (job.employerId !== ctx.user.id && ctx.user.role !== "админ") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return deleteJob(input.id);
    }),
});

// ─── Applications ─────────────────────────────────────────────────────────────

const applicationsRouter = router({
  submit: protectedProcedure
    .input(
      z.object({
        jobId: z.number(),
        coverLetter: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "соискатель") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Только соискатели могут откликаться на вакансии" });
      }
      const existing = await checkExistingApplication(input.jobId, ctx.user.id);
      if (existing) {
        throw new TRPCError({ code: "CONFLICT", message: "Вы уже откликнулись на эту вакансию" });
      }
      await createApplication({ ...input, seekerId: ctx.user.id });

      // Notify employer
      const job = await getJobById(input.jobId);
      if (job) {
        await notifyOwner({
          title: `Новый отклик на вакансию: ${job.title}`,
          content: `Соискатель ${ctx.user.name || ctx.user.email} откликнулся на вакансию "${job.title}" в компании ${job.company}.`,
        });
      }
      return { success: true };
    }),

  myApplications: protectedProcedure.query(({ ctx }) =>
    getApplicationsBySeeker(ctx.user.id)
  ),

  jobApplications: protectedProcedure
    .input(z.object({ jobId: z.number() }))
    .query(async ({ ctx, input }) => {
      const job = await getJobById(input.jobId);
      if (!job) throw new TRPCError({ code: "NOT_FOUND" });
      if (job.employerId !== ctx.user.id && ctx.user.role !== "админ") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return getApplicationsByJob(input.jobId);
    }),

  updateStatus: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["новый", "просмотрен", "приглашён", "отказ"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const app = await getApplicationById(input.id);
      if (!app) throw new TRPCError({ code: "NOT_FOUND" });
      const job = await getJobById(app.jobId);
      if (!job) throw new TRPCError({ code: "NOT_FOUND" });
      if (job.employerId !== ctx.user.id && ctx.user.role !== "админ") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      await updateApplicationStatus(input.id, input.status);

      // Notify seeker
      await notifyOwner({
        title: `Статус отклика изменён`,
        content: `Статус вашего отклика на вакансию "${job.title}" изменён на: ${input.status}`,
      });
      return { success: true };
    }),

  checkApplied: protectedProcedure
    .input(z.object({ jobId: z.number() }))
    .query(({ ctx, input }) => checkExistingApplication(input.jobId, ctx.user.id)),
});

// ─── Saved Jobs ───────────────────────────────────────────────────────────────

const savedJobsRouter = router({
  list: protectedProcedure.query(({ ctx }) => getSavedJobs(ctx.user.id)),

  toggle: protectedProcedure
    .input(z.object({ jobId: z.number() }))
    .mutation(({ ctx, input }) => toggleSavedJob(ctx.user.id, input.jobId)),

  isSaved: protectedProcedure
    .input(z.object({ jobId: z.number() }))
    .query(({ ctx, input }) => isSavedJob(ctx.user.id, input.jobId)),
});

// ─── Seeker Profile ───────────────────────────────────────────────────────────

const seekerRouter = router({
  profile: protectedProcedure.query(({ ctx }) => getSeekerProfile(ctx.user.id)),

  updateProfile: protectedProcedure
    .input(
      z.object({
        phone: z.string().optional(),
        city: z.string().optional(),
        bio: z.string().optional(),
        professionId: z.number().optional(),
      })
    )
    .mutation(({ ctx, input }) => upsertSeekerProfile(ctx.user.id, input)),

  uploadResume: protectedProcedure
    .input(
      z.object({
        fileName: z.string(),
        fileBase64: z.string(),
        mimeType: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const buffer = Buffer.from(input.fileBase64, "base64");
      const key = `resumes/${ctx.user.id}/${Date.now()}-${input.fileName}`;
      const { url } = await storagePut(key, buffer, input.mimeType);
      await upsertSeekerProfile(ctx.user.id, { resumeUrl: url, resumeKey: key });
      return { url, key };
    }),

  uploadPhoto: protectedProcedure
    .input(
      z.object({
        fileName: z.string(),
        fileBase64: z.string(),
        mimeType: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const buffer = Buffer.from(input.fileBase64, "base64");
      const key = `photos/${ctx.user.id}/${Date.now()}-${input.fileName}`;
      const { url } = await storagePut(key, buffer, input.mimeType);
      await upsertSeekerProfile(ctx.user.id, { photoUrl: url, photoKey: key });
      return { url, key };
    }),

  getProfileById: protectedProcedure
    .input(z.object({ userId: z.number() }))
    .query(async ({ ctx }) => {
      // Employers and admins can view seeker profiles
      if (ctx.user.role !== "работодатель" && ctx.user.role !== "админ") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return undefined; // handled by input below
    }),

  getProfileByIdFull: protectedProcedure
    .input(z.object({ userId: z.number() }))
    .query(async ({ ctx, input }) => {
      if (ctx.user.role !== "работодатель" && ctx.user.role !== "админ" && ctx.user.id !== input.userId) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return getSeekerProfileWithUser(input.userId);
    }),
});

// ─── Employer Profile ─────────────────────────────────────────────────────────

const employerRouter = router({
  profile: protectedProcedure.query(({ ctx }) => getEmployerProfile(ctx.user.id)),

  updateProfile: protectedProcedure
    .input(
      z.object({
        companyName: z.string().optional(),
        companyDescription: z.string().optional(),
        website: z.string().optional(),
        phone: z.string().optional(),
        city: z.string().optional(),
      })
    )
    .mutation(({ ctx, input }) => upsertEmployerProfile(ctx.user.id, input)),
});

// ─── Admin ────────────────────────────────────────────────────────────────────

const adminRouter = router({
  users: adminProcedure
    .input(z.object({ page: z.number().default(1) }))
    .query(({ input }) => getAllUsers(input.page)),

  updateUserRole: adminProcedure
    .input(
      z.object({
        userId: z.number(),
        role: z.enum(["соискатель", "работодатель", "админ"]),
      })
    )
    .mutation(({ input }) => updateUserRole(input.userId, input.role)),

  stats: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) return { jobs: 0, users: 0, applications: 0 };
    const [{ jobCount }] = await db
      .select({ jobCount: sql`count(*)` })
      .from(jobs)
      .where(eq(jobs.status, "активна"));
    const [{ userCount }] = await db.select({ userCount: sql`count(*)` }).from(users);
    const [{ appCount }] = await db.select({ appCount: sql`count(*)` }).from(applications);
    return {
      jobs: Number(jobCount),
      users: Number(userCount),
      applications: Number(appCount),
    };
  }),
});

// ─── Chat ────────────────────────────────────────────────────────────────────

const chatRouter = router({
  messages: protectedProcedure
    .input(z.object({ applicationId: z.number() }))
    .query(async ({ ctx, input }) => {
      const app = await getApplicationById(input.applicationId);
      if (!app) throw new TRPCError({ code: "NOT_FOUND" });
      // Access: seeker who applied, or employer who owns the job, or admin
      const job = await getJobById(app.jobId);
      const isSeeker = app.seekerId === ctx.user.id;
      const isEmployer = job?.employerId === ctx.user.id;
      if (!isSeeker && !isEmployer && ctx.user.role !== "админ") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return getChatMessages(input.applicationId);
    }),

  send: protectedProcedure
    .input(z.object({ applicationId: z.number(), text: z.string().min(1).max(2000) }))
    .mutation(async ({ ctx, input }) => {
      const app = await getApplicationById(input.applicationId);
      if (!app) throw new TRPCError({ code: "NOT_FOUND" });
      const job = await getJobById(app.jobId);
      const isSeeker = app.seekerId === ctx.user.id;
      const isEmployer = job?.employerId === ctx.user.id;
      if (!isSeeker && !isEmployer && ctx.user.role !== "админ") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return sendChatMessage(input.applicationId, ctx.user.id, input.text);
    }),
});

// ─── Export ──────────────────────────────────────────────────────────────────────────────

const exportRouter = router({
  applicationsCSV: protectedProcedure
    .input(z.object({ jobId: z.number().optional() }))
    .query(async ({ ctx, input }) => {
      if (ctx.user.role !== "работодатель" && ctx.user.role !== "админ") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return getApplicationsForExport(ctx.user.id, input.jobId);
    }),
});

// ─── User ─────────────────────────────────────────────────────────────────────────────────

const userRouter = router({
  setRole: protectedProcedure
    .input(z.object({ role: z.enum(["соискатель", "работодатель"]) }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role === "админ") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Нельзя изменить роль администратора" });
      }
      await updateUserRole(ctx.user.id, input.role);
      return { success: true };
    }),
});

// ─── App Router ───────────────────────────────────────────────────────────────

import { sql } from "drizzle-orm";
import { incrementJobViews } from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  professions: professionsRouter,
  jobs: jobsRouter,
  applications: applicationsRouter,
  savedJobs: savedJobsRouter,
  seeker: seekerRouter,
  employer: employerRouter,
  admin: adminRouter,
  user: userRouter,
  chat: chatRouter,
  export: exportRouter,
});

export type AppRouter = typeof appRouter;
