import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createContext(overrides?: Partial<TrpcContext>): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
    ...overrides,
  };
}

function createUserContext(role: "соискатель" | "работодатель" | "админ" = "соискатель") {
  return createContext({
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "manus",
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
  });
}

describe("auth.me", () => {
  it("returns null for unauthenticated user", async () => {
    const caller = appRouter.createCaller(createContext());
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });

  it("returns user for authenticated user", async () => {
    const ctx = createUserContext("соискатель");
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.me();
    expect(result?.role).toBe("соискатель");
  });
});

describe("professions.list", () => {
  it("is accessible without authentication", async () => {
    const caller = appRouter.createCaller(createContext());
    // Should not throw UNAUTHORIZED
    await expect(caller.professions.list()).resolves.toBeDefined();
  });
});

describe("jobs.list", () => {
  it("is accessible without authentication", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.jobs.list({ page: 1, limit: 10 })).resolves.toBeDefined();
  });

  it("returns paginated results", async () => {
    const caller = appRouter.createCaller(createContext());
    const result = await caller.jobs.list({ page: 1, limit: 5 });
    expect(result).toHaveProperty("items");
    expect(result).toHaveProperty("total");
    expect(Array.isArray(result.items)).toBe(true);
  });
});

describe("jobs.create", () => {
  it("throws FORBIDDEN for non-employer", async () => {
    const ctx = createUserContext("соискатель");
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.jobs.create({
        title: "Test Job",
        description: "Test description that is long enough",
        company: "Test Co",
        city: "Moscow",
        employmentType: "полная",
        professionId: 1,
        status: "активна",
      })
    ).rejects.toThrow();
  });
});

describe("applications.submit", () => {
  it("throws UNAUTHORIZED for unauthenticated user", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.applications.submit({ jobId: 1 })
    ).rejects.toThrow();
  });

  it("throws FORBIDDEN for employer trying to apply", async () => {
    const ctx = createUserContext("работодатель");
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.applications.submit({ jobId: 1 })
    ).rejects.toThrow();
  });
});

describe("user.setRole", () => {
  it("throws UNAUTHORIZED for unauthenticated user", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.user.setRole({ role: "работодатель" })
    ).rejects.toThrow();
  });
});

describe("admin procedures", () => {
  it("throws FORBIDDEN for non-admin on stats", async () => {
    const ctx = createUserContext("соискатель");
    const caller = appRouter.createCaller(ctx);
    await expect(caller.admin.stats()).rejects.toThrow();
  });

  it("throws FORBIDDEN for non-admin on users list", async () => {
    const ctx = createUserContext("работодатель");
    const caller = appRouter.createCaller(ctx);
    await expect(caller.admin.users({ page: 1 })).rejects.toThrow();
  });
});
