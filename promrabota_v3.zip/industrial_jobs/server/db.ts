import { and, desc, eq, gte, ilike, like, lte, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  applications,
  employerProfiles,
  InsertApplication,
  InsertEmployerProfile,
  InsertJob,
  InsertProfession,
  InsertSeekerProfile,
  InsertUser,
  jobs,
  messages,
  professions,
  savedJobs,
  seekerProfiles,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ───────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};

  const textFields = ["name", "email", "loginMethod"] as const;
  type TextField = (typeof textFields)[number];
  const assignNullable = (field: TextField) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  };
  textFields.forEach(assignNullable);

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "админ";
    updateSet.role = "админ";
  }

  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getAllUsers(page = 1, limit = 50) {
  const db = await getDb();
  if (!db) return { items: [], total: 0 };
  const offset = (page - 1) * limit;
  const items = await db.select().from(users).orderBy(desc(users.createdAt)).limit(limit).offset(offset);
  const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(users);
  return { items, total: Number(count) };
}

export async function updateUserRole(userId: number, role: "соискатель" | "работодатель" | "админ") {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ role }).where(eq(users.id, userId));
}

// ─── Professions ─────────────────────────────────────────────────────────────

export async function getProfessions() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(professions).where(eq(professions.isActive, true)).orderBy(professions.name);
}

export async function getAllProfessions() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(professions).orderBy(professions.name);
}

export async function createProfession(data: InsertProfession) {
  const db = await getDb();
  if (!db) return;
  await db.insert(professions).values(data);
}

export async function updateProfession(id: number, data: Partial<InsertProfession>) {
  const db = await getDb();
  if (!db) return;
  await db.update(professions).set(data).where(eq(professions.id, id));
}

export async function deleteProfession(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(professions).set({ isActive: false }).where(eq(professions.id, id));
}

// ─── Jobs ─────────────────────────────────────────────────────────────────────

export async function getJobs(opts: {
  search?: string;
  professionId?: number;
  city?: string;
  employmentType?: string;
  salaryMin?: number;
  salaryMax?: number;
  page?: number;
  limit?: number;
  status?: string;
  employerId?: number;
}) {
  const db = await getDb();
  if (!db) return { items: [], total: 0 };

  const { search, professionId, city, employmentType, salaryMin, salaryMax, page = 1, limit = 20, status = "активна", employerId } = opts;
  const offset = (page - 1) * limit;

  const conditions = [];
  if (status) conditions.push(eq(jobs.status, status as "активна" | "закрыта" | "черновик"));
  if (employerId) conditions.push(eq(jobs.employerId, employerId));
  if (professionId) conditions.push(eq(jobs.professionId, professionId));
  if (city) conditions.push(like(jobs.city, `%${city}%`));
  if (employmentType) conditions.push(eq(jobs.employmentType, employmentType as "полная" | "частичная" | "вахта" | "договор"));
  if (salaryMin) conditions.push(gte(jobs.salaryFrom, salaryMin));
  if (salaryMax) conditions.push(lte(jobs.salaryTo, salaryMax));
  if (search) {
    conditions.push(
      or(
        like(jobs.title, `%${search}%`),
        like(jobs.company, `%${search}%`),
        like(jobs.city, `%${search}%`)
      )
    );
  }

  const where = conditions.length > 0 ? and(...conditions) : undefined;

  const items = await db
    .select({
      id: jobs.id,
      title: jobs.title,
      company: jobs.company,
      city: jobs.city,
      salaryFrom: jobs.salaryFrom,
      salaryTo: jobs.salaryTo,
      currency: jobs.currency,
      employmentType: jobs.employmentType,
      professionId: jobs.professionId,
      status: jobs.status,
      createdAt: jobs.createdAt,
      professionName: professions.name,
    })
    .from(jobs)
    .leftJoin(professions, eq(jobs.professionId, professions.id))
    .where(where)
    .orderBy(desc(jobs.createdAt))
    .limit(limit)
    .offset(offset);

  const [{ count }] = await db
    .select({ count: sql<number>`count(*)` })
    .from(jobs)
    .leftJoin(professions, eq(jobs.professionId, professions.id))
    .where(where);

  return { items, total: Number(count) };
}

export async function getJobById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select({
      id: jobs.id,
      title: jobs.title,
      description: jobs.description,
      requirements: jobs.requirements,
      company: jobs.company,
      city: jobs.city,
      salaryFrom: jobs.salaryFrom,
      salaryTo: jobs.salaryTo,
      currency: jobs.currency,
      employmentType: jobs.employmentType,
      professionId: jobs.professionId,
      employerId: jobs.employerId,
      status: jobs.status,
      viewsCount: jobs.viewsCount,
      createdAt: jobs.createdAt,
      updatedAt: jobs.updatedAt,
      professionName: professions.name,
    })
    .from(jobs)
    .leftJoin(professions, eq(jobs.professionId, professions.id))
    .where(eq(jobs.id, id))
    .limit(1);
  return result[0];
}

export async function createJob(data: InsertJob) {
  const db = await getDb();
  if (!db) return;
  const result = await db.insert(jobs).values(data);
  return result;
}

export async function updateJob(id: number, data: Partial<InsertJob>) {
  const db = await getDb();
  if (!db) return;
  await db.update(jobs).set(data).where(eq(jobs.id, id));
}

export async function deleteJob(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(jobs).set({ status: "закрыта" }).where(eq(jobs.id, id));
}

export async function incrementJobViews(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(jobs).set({ viewsCount: sql`${jobs.viewsCount} + 1` }).where(eq(jobs.id, id));
}

// ─── Applications ─────────────────────────────────────────────────────────────

export async function createApplication(data: InsertApplication) {
  const db = await getDb();
  if (!db) return;
  await db.insert(applications).values(data);
}

export async function getApplicationsBySeeker(seekerId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: applications.id,
      jobId: applications.jobId,
      status: applications.status,
      coverLetter: applications.coverLetter,
      createdAt: applications.createdAt,
      updatedAt: applications.updatedAt,
      jobTitle: jobs.title,
      company: jobs.company,
      city: jobs.city,
    })
    .from(applications)
    .leftJoin(jobs, eq(applications.jobId, jobs.id))
    .where(eq(applications.seekerId, seekerId))
    .orderBy(desc(applications.createdAt));
}

export async function getApplicationsByJob(jobId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: applications.id,
      seekerId: applications.seekerId,
      status: applications.status,
      coverLetter: applications.coverLetter,
      createdAt: applications.createdAt,
      seekerName: users.name,
      seekerEmail: users.email,
    })
    .from(applications)
    .leftJoin(users, eq(applications.seekerId, users.id))
    .where(eq(applications.jobId, jobId))
    .orderBy(desc(applications.createdAt));
}

export async function updateApplicationStatus(
  id: number,
  status: "новый" | "просмотрен" | "приглашён" | "отказ"
) {
  const db = await getDb();
  if (!db) return;
  await db.update(applications).set({ status }).where(eq(applications.id, id));
}

export async function getApplicationById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(applications).where(eq(applications.id, id)).limit(1);
  return result[0];
}

export async function checkExistingApplication(jobId: number, seekerId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(applications)
    .where(and(eq(applications.jobId, jobId), eq(applications.seekerId, seekerId)))
    .limit(1);
  return result[0];
}

// ─── Saved Jobs ───────────────────────────────────────────────────────────────

export async function getSavedJobs(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: savedJobs.id,
      jobId: savedJobs.jobId,
      createdAt: savedJobs.createdAt,
      jobTitle: jobs.title,
      company: jobs.company,
      city: jobs.city,
      salaryFrom: jobs.salaryFrom,
      salaryTo: jobs.salaryTo,
      currency: jobs.currency,
      employmentType: jobs.employmentType,
      professionName: professions.name,
      jobStatus: jobs.status,
    })
    .from(savedJobs)
    .leftJoin(jobs, eq(savedJobs.jobId, jobs.id))
    .leftJoin(professions, eq(jobs.professionId, professions.id))
    .where(eq(savedJobs.userId, userId))
    .orderBy(desc(savedJobs.createdAt));
}

export async function toggleSavedJob(userId: number, jobId: number) {
  const db = await getDb();
  if (!db) return { saved: false };
  const existing = await db
    .select()
    .from(savedJobs)
    .where(and(eq(savedJobs.userId, userId), eq(savedJobs.jobId, jobId)))
    .limit(1);

  if (existing.length > 0) {
    await db.delete(savedJobs).where(and(eq(savedJobs.userId, userId), eq(savedJobs.jobId, jobId)));
    return { saved: false };
  } else {
    await db.insert(savedJobs).values({ userId, jobId });
    return { saved: true };
  }
}

export async function isSavedJob(userId: number, jobId: number) {
  const db = await getDb();
  if (!db) return false;
  const result = await db
    .select()
    .from(savedJobs)
    .where(and(eq(savedJobs.userId, userId), eq(savedJobs.jobId, jobId)))
    .limit(1);
  return result.length > 0;
}

// ─── Seeker Profiles ──────────────────────────────────────────────────────────

export async function getSeekerProfile(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(seekerProfiles).where(eq(seekerProfiles.userId, userId)).limit(1);
  return result[0];
}

export async function upsertSeekerProfile(userId: number, data: Partial<InsertSeekerProfile>) {
  const db = await getDb();
  if (!db) return;
  const existing = await getSeekerProfile(userId);
  if (existing) {
    await db.update(seekerProfiles).set(data).where(eq(seekerProfiles.userId, userId));
  } else {
    await db.insert(seekerProfiles).values({ userId, ...data });
  }
}

export async function getSeekerProfileWithUser(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select({
      profile: seekerProfiles,
      user: { name: users.name, email: users.email },
    })
    .from(seekerProfiles)
    .leftJoin(users, eq(seekerProfiles.userId, users.id))
    .where(eq(seekerProfiles.userId, userId))
    .limit(1);
  return result[0];
}

// ─── Employer Profiles ────────────────────────────────────────────────────────

export async function getEmployerProfile(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(employerProfiles).where(eq(employerProfiles.userId, userId)).limit(1);
  return result[0];
}

export async function upsertEmployerProfile(userId: number, data: Partial<InsertEmployerProfile>) {
  const db = await getDb();
  if (!db) return;
  const existing = await getEmployerProfile(userId);
  if (existing) {
    await db.update(employerProfiles).set(data).where(eq(employerProfiles.userId, userId));
  } else {
    await db.insert(employerProfiles).values({ userId, ...data });
  }
}

// ─── Chat Messages ────────────────────────────────────────────────────────────

export async function getChatMessages(applicationId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: messages.id,
      applicationId: messages.applicationId,
      senderId: messages.senderId,
      text: messages.text,
      createdAt: messages.createdAt,
      senderName: users.name,
    })
    .from(messages)
    .leftJoin(users, eq(messages.senderId, users.id))
    .where(eq(messages.applicationId, applicationId))
    .orderBy(messages.createdAt);
}

export async function sendChatMessage(applicationId: number, senderId: number, text: string) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(messages).values({ applicationId, senderId, text });
  const result = await db
    .select()
    .from(messages)
    .where(eq(messages.applicationId, applicationId))
    .orderBy(desc(messages.createdAt))
    .limit(1);
  return result[0];
}

// ─── Applications Export ──────────────────────────────────────────────────────

export async function getApplicationsForExport(employerId: number, jobId?: number) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(jobs.employerId, employerId)];
  if (jobId) conditions.push(eq(applications.jobId, jobId));
  return db
    .select({
      id: applications.id,
      status: applications.status,
      coverLetter: applications.coverLetter,
      createdAt: applications.createdAt,
      jobTitle: jobs.title,
      jobCity: jobs.city,
      seekerName: users.name,
      seekerEmail: users.email,
    })
    .from(applications)
    .innerJoin(jobs, eq(applications.jobId, jobs.id))
    .leftJoin(users, eq(applications.seekerId, users.id))
    .where(and(...conditions))
    .orderBy(desc(applications.createdAt));
}
