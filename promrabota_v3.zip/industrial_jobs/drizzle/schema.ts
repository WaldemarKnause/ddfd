import {
  boolean,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  bigint,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["соискатель", "работодатель", "админ"]).default("соискатель").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Профессии / категории
export const professions = mysqlTable("professions", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 128 }).notNull().unique(),
  slug: varchar("slug", { length: 128 }).notNull().unique(),
  description: text("description"),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Profession = typeof professions.$inferSelect;
export type InsertProfession = typeof professions.$inferInsert;

// Вакансии
export const jobs = mysqlTable("jobs", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 256 }).notNull(),
  description: text("description").notNull(),
  requirements: text("requirements"),
  company: varchar("company", { length: 256 }).notNull(),
  city: varchar("city", { length: 128 }).notNull(),
  salaryFrom: int("salaryFrom"),
  salaryTo: int("salaryTo"),
  currency: varchar("currency", { length: 8 }).default("₽").notNull(),
  employmentType: mysqlEnum("employmentType", ["полная", "частичная", "вахта", "договор"]).default("полная").notNull(),
  professionId: int("professionId").notNull(),
  employerId: int("employerId").notNull(),
  status: mysqlEnum("status", ["активна", "закрыта", "черновик"]).default("активна").notNull(),
  viewsCount: int("viewsCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Job = typeof jobs.$inferSelect;
export type InsertJob = typeof jobs.$inferInsert;

// Отклики
export const applications = mysqlTable("applications", {
  id: int("id").autoincrement().primaryKey(),
  jobId: int("jobId").notNull(),
  seekerId: int("seekerId").notNull(),
  coverLetter: text("coverLetter"),
  status: mysqlEnum("status", ["новый", "просмотрен", "приглашён", "отказ"]).default("новый").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Application = typeof applications.$inferSelect;
export type InsertApplication = typeof applications.$inferInsert;

// Сохранённые вакансии
export const savedJobs = mysqlTable("saved_jobs", {
  id: int("id").autoincrement().primaryKey(),
  jobId: int("jobId").notNull(),
  userId: int("userId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SavedJob = typeof savedJobs.$inferSelect;

// Профили соискателей
export const seekerProfiles = mysqlTable("seeker_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  phone: varchar("phone", { length: 32 }),
  city: varchar("city", { length: 128 }),
  bio: text("bio"),
  professionId: int("professionId"),
  resumeUrl: text("resumeUrl"),
  resumeKey: text("resumeKey"),
  photoUrl: text("photoUrl"),
  photoKey: text("photoKey"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SeekerProfile = typeof seekerProfiles.$inferSelect;
export type InsertSeekerProfile = typeof seekerProfiles.$inferInsert;

// Профили работодателей
export const employerProfiles = mysqlTable("employer_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  companyName: varchar("companyName", { length: 256 }),
  companyDescription: text("companyDescription"),
  website: varchar("website", { length: 256 }),
  phone: varchar("phone", { length: 32 }),
  city: varchar("city", { length: 128 }),
  logoUrl: text("logoUrl"),
  logoKey: text("logoKey"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type EmployerProfile = typeof employerProfiles.$inferSelect;
export type InsertEmployerProfile = typeof employerProfiles.$inferInsert;

// Локальная авторизация (email + пароль)
export const localAuth = mysqlTable("local_auth", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  passwordHash: varchar("passwordHash", { length: 256 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type LocalAuth = typeof localAuth.$inferSelect;
export type InsertLocalAuth = typeof localAuth.$inferInsert;

// Сообщения чата в откликах
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  applicationId: int("applicationId").notNull(),
  senderId: int("senderId").notNull(),
  text: text("text").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;
