CREATE TABLE `applications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`jobId` int NOT NULL,
	`seekerId` int NOT NULL,
	`coverLetter` text,
	`status` enum('новый','просмотрен','приглашён','отказ') NOT NULL DEFAULT 'новый',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `applications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `employer_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`companyName` varchar(256),
	`companyDescription` text,
	`website` varchar(256),
	`phone` varchar(32),
	`city` varchar(128),
	`logoUrl` text,
	`logoKey` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `employer_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `employer_profiles_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `jobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(256) NOT NULL,
	`description` text NOT NULL,
	`requirements` text,
	`company` varchar(256) NOT NULL,
	`city` varchar(128) NOT NULL,
	`salaryFrom` int,
	`salaryTo` int,
	`currency` varchar(8) NOT NULL DEFAULT '₽',
	`employmentType` enum('полная','частичная','вахта','договор') NOT NULL DEFAULT 'полная',
	`professionId` int NOT NULL,
	`employerId` int NOT NULL,
	`status` enum('активна','закрыта','черновик') NOT NULL DEFAULT 'активна',
	`viewsCount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `jobs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `professions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(128) NOT NULL,
	`slug` varchar(128) NOT NULL,
	`description` text,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `professions_id` PRIMARY KEY(`id`),
	CONSTRAINT `professions_name_unique` UNIQUE(`name`),
	CONSTRAINT `professions_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `saved_jobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`jobId` int NOT NULL,
	`userId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `saved_jobs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `seeker_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`phone` varchar(32),
	`city` varchar(128),
	`bio` text,
	`professionId` int,
	`resumeUrl` text,
	`resumeKey` text,
	`photoUrl` text,
	`photoKey` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `seeker_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `seeker_profiles_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('соискатель','работодатель','админ') NOT NULL DEFAULT 'соискатель';