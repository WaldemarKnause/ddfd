@echo off
chcp 65001 >nul
title ПромРабота — Установка и запуск

echo.
echo ╔══════════════════════════════════════════╗
echo ║      ПромРабота — Первый запуск          ║
echo ╚══════════════════════════════════════════╝
echo.

REM --- Проверяем Node.js ---
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ОШИБКА] Node.js не установлен!
    echo.
    echo Установи Node.js с сайта: https://nodejs.org
    echo Скачай версию LTS, при установке поставь галочку "Add to PATH"
    echo После установки закрой это окно и запусти снова.
    echo.
    pause
    exit /b 1
)
echo [OK] Node.js найден

REM --- Проверяем pnpm ---
pnpm --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [..] Устанавливаем pnpm...
    npm install -g pnpm
)
echo [OK] pnpm найден

REM --- Создаём .env если нет ---
if not exist ".env" (
    if exist ".env.example" (
        copy ".env.example" ".env" >nul
        echo [OK] Создан файл .env
    )
)

REM --- Устанавливаем зависимости если нет node_modules ---
if not exist "node_modules" (
    echo.
    echo [..] Устанавливаем зависимости (1-3 минуты, подожди)...
    pnpm install
    if %errorlevel% neq 0 (
        echo [ОШИБКА] Не удалось установить зависимости
        pause
        exit /b 1
    )
    echo [OK] Зависимости установлены
)

REM --- Применяем миграции БД ---
echo.
echo [..] Настраиваем базу данных...
echo     (MySQL должен быть запущен в XAMPP!)
echo.
set DATABASE_URL=mysql://root:@localhost:3306/industrial_jobs
pnpm drizzle-kit migrate
if %errorlevel% neq 0 (
    echo.
    echo [ВНИМАНИЕ] Не удалось применить миграции автоматически.
    echo Открой phpMyAdmin (http://localhost/phpmyadmin),
    echo создай базу "industrial_jobs" и импортируй файл "database_setup.sql"
    echo.
    echo После этого нажми любую клавишу для продолжения...
    pause >nul
)

REM --- Запускаем сервер ---
echo.
echo [OK] Запускаем сервер...
echo.
echo ══════════════════════════════════════════
echo   Сайт будет доступен: http://localhost:3000
echo   Для остановки нажми Ctrl+C
echo ══════════════════════════════════════════
echo.
pnpm dev
pause
